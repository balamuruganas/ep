﻿function OnBeginLoginUser() {
    DisableForm();
}

function OnSuccessLoginUser(data) {
    EnableForm();
    if (data != undefined) {
        if (data.HasErrors != undefined && data.HasErrors)
        {
            $("#divLoginError").removeClass("hide");
            var customError = data.Errors.length > 1 ? data.Errors[1] : data.Errors[0];
            $("#pLoginErrorMessage").html(customError);
        }
      
        else if (data.Success != undefined && data.Success) {
            $("#LoginForm .alert-warning").addClass("hide");
            location.href = $("#loginReturnUlr").val();
            GaTrack_SignIn(window.location.origin + $("#loginReturnUlr").val())
        }
        else
        {
            console.log(data);
        }
    }
}

function OnFailureLoginUser(data) {
    EnableForm();
}

function ClearResult() {

}