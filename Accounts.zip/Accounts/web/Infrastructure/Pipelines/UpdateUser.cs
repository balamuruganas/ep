﻿namespace Echopark.Feature.Accounts.Infrastructure.Pipelines
{
    using Sitecore.Commerce.Core.Commands;
    using Sitecore.Commerce.Engine;
    using Sitecore.Commerce.Engine.Connect.Pipelines;
    using Sitecore.Commerce.Entities.Customers;
    using Sitecore.Commerce.EntityViews;
    using Sitecore.Commerce.Pipelines;
    using Sitecore.Commerce.Services.Customers;
    using Sitecore.Diagnostics;
    using System;
    using System.Linq;

    public class UpdateUser : PipelineProcessor
    {
        public override void Process(ServicePipelineArgs args)
        {
            PipelineUtility.ValidateArguments<UpdateUserRequest, UpdateUserResult>(args, out var request, out var result);
            Assert.IsNotNull(request.CommerceUser, "request.CommerceUser");
            Assert.IsNotNull(request.CommerceUser.ExternalId, "request.CommerceUser.ExternalId");
            Assert.IsNotNull(request.Shop, "request.Shop");
            Container container = GetContainer(request.Shop.Name, request.CommerceUser.ExternalId, "", "", args.Request.CurrencyCode);
            string externalId = request.CommerceUser.ExternalId;
            EntityView entityView = GetEntityView(container, externalId, string.Empty, "Details", "EditCustomer", result);
            if (result.Success)
            {
                foreach (Sitecore.Commerce.PropertyItem property in request.Properties)
                {
                    ViewProperty propertyExist = entityView.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals(property.Key, StringComparison.OrdinalIgnoreCase));

                    if (propertyExist == null)
                    {
                        entityView.Properties.Add(new ViewProperty()
                        {
                            Name = property.Key,
                            Value = property.Value?.ToString()
                        });
                    }
                    else
                    {
                        propertyExist.Name = property.Key;
                        propertyExist.Value = property.Value?.ToString();
                    }
                }
                TranslateCommerceUserToView(entityView, request.CommerceUser);
                CommerceCommand commerceCommand = DoAction(container, entityView, result);
                if (commerceCommand != null && commerceCommand.ResponseCode.Equals("ok", StringComparison.OrdinalIgnoreCase))
                {
                    result.CommerceUser = request.CommerceUser;
                }
                base.Process(args);
            }
        }

        protected virtual void TranslateCommerceUserToView(EntityView view, CommerceUser commerceUser)
        {
            view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("UserName", StringComparison.OrdinalIgnoreCase)).Value = commerceUser.UserName;
            view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("Email", StringComparison.OrdinalIgnoreCase)).Value = commerceUser.Email;
            view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("AccountStatus", StringComparison.OrdinalIgnoreCase)).Value = (commerceUser.IsDisabled ? "InactiveAccount" : "ActiveAccount");
            view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("FirstName", StringComparison.OrdinalIgnoreCase)).Value = commerceUser.FirstName;
            view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("LastName", StringComparison.OrdinalIgnoreCase)).Value = commerceUser.LastName;
            string text = commerceUser.GetProperties().Keys.FirstOrDefault((string k) => k.Equals("Phone", StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrWhiteSpace(text))
            {
                view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("PhoneNumber", StringComparison.OrdinalIgnoreCase)).Value = commerceUser.GetPropertyValue(text)?.ToString();
            }
        }
    }
}