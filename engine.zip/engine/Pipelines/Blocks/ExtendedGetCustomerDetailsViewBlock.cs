﻿using Sitecore.Commerce.Core;
using Sitecore.Commerce.EntityViews;
using Sitecore.Commerce.Plugin.Customers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Echopark.Plugin.Customers.Pipelines.Blocks
{
    public class ExtendedGetCustomerDetailsViewBlock : Sitecore.Commerce.Plugin.Customers.GetCustomerDetailsViewBlock
    {
        public ExtendedGetCustomerDetailsViewBlock(IGetLocalizedCustomerStatusPipeline getLocalizedCustomerStatusPipeline) : base(getLocalizedCustomerStatusPipeline)
        {
        }
        protected override async Task PopulateDetails(EntityView view, Customer customer, bool isAddAction, bool isEditAction, CommercePipelineExecutionContext context)
        {
            await base.PopulateDetails(view, customer, isAddAction, isEditAction, context);

            if (view == null)
            {
                return;
            }
            EntityView details = null;
            if (customer != null && customer.HasComponent<CustomerDetailsComponent>())
            {
                details = customer.GetComponent<CustomerDetailsComponent>().View.ChildViews.FirstOrDefault((Model v) => v.Name.Equals("Details", StringComparison.OrdinalIgnoreCase)) as EntityView;
            }

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "DOB",
                RawValue = details?.GetPropertyValue("DOB"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "ReceiveEchoparkCommunications",
                RawValue = details?.GetPropertyValue("ReceiveEchoparkCommunications"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PreferredVehicleMake",
                RawValue = details?.GetPropertyValue("PreferredVehicleMake"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PreferredVehicleModel",
                RawValue = details?.GetPropertyValue("PreferredVehicleModel"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CurrentVehicleMake",
                RawValue = details?.GetPropertyValue("CurrentVehicleMake"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CurrentVehicleModel",
                RawValue = details?.GetPropertyValue("CurrentVehicleModel"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GeneralEmailAlert",
                RawValue = details?.GetPropertyValue("GeneralEmailAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GeneralSMSAlert",
                RawValue = details?.GetPropertyValue("GeneralSMSAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PriceDropEmailAlert",
                RawValue = details?.GetPropertyValue("PriceDropEmailAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PriceDropSMSAlert",
                RawValue = details?.GetPropertyValue("PriceDropSMSAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CarSoldEmailAlert",
                RawValue = details?.GetPropertyValue("CarSoldEmailAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CarSoldSMSAlert",
                RawValue = details?.GetPropertyValue("CarSoldSMSAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "DealerCommunicationAlert",
                RawValue = details?.GetPropertyValue("DealerCommunicationAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "SSN",
                RawValue = details?.GetPropertyValue("SSN"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GetSMSCommunications",
                RawValue = details?.GetPropertyValue("GetSMSCommunications"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GetEmailCommunications",
                RawValue = details?.GetPropertyValue("GetEmailCommunications"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "VIN",
                RawValue = details?.GetPropertyValue("VIN"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });


            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Make",
                RawValue = details?.GetPropertyValue("Make"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Model",
                RawValue = details?.GetPropertyValue("Model"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Year",
                RawValue = details?.GetPropertyValue("Year"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Trim",
                RawValue = details?.GetPropertyValue("Trim"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Year",
                RawValue = details?.GetPropertyValue("Year"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Trim",
                RawValue = details?.GetPropertyValue("Trim"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "OfferValue",
                RawValue = details?.GetPropertyValue("OfferValue"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "OfferExpiration",
                RawValue = details?.GetPropertyValue("OfferExpiration"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Mileage",
                RawValue = details?.GetPropertyValue("Mileage"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
        }
    }
}
                  