﻿using Sitecore.Commerce.Core;
using Sitecore.Commerce.EntityViews;
using Sitecore.Commerce.Plugin.Customers;
using Sitecore.Commerce.Plugin.Shops;
using Sitecore.Framework.Conditions;
using Sitecore.Framework.Pipelines;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Echopark.Plugin.Customers
{
    [PipelineDisplayName("Customers.blocks.getcustomerdetailsView")]
    public class GetCustomerDetailsViewBlock : AsyncPipelineBlock<EntityView, EntityView, CommercePipelineExecutionContext>
    {
        private readonly IGetLocalizedCustomerStatusPipeline _getLocalizedCustomerStatusPipeline;

        public GetCustomerDetailsViewBlock(IGetLocalizedCustomerStatusPipeline getLocalizedCustomerStatusPipeline)
            : base((string)null)
        {
            _getLocalizedCustomerStatusPipeline = getLocalizedCustomerStatusPipeline;
        }

        public override async Task<EntityView> RunAsync(EntityView arg, CommercePipelineExecutionContext context)
        {
            Condition.Requires(arg).IsNotNull(base.Name + ": The argument cannot be null");
            EntityViewArgument @object = context.CommerceContext.GetObject<EntityViewArgument>();
            if (string.IsNullOrEmpty(@object?.ViewName) || (!@object.ViewName.Equals(context.GetPolicy<KnownCustomerViewsPolicy>().Details, StringComparison.OrdinalIgnoreCase) && !@object.ViewName.Equals(context.GetPolicy<KnownCustomerViewsPolicy>().Master, StringComparison.OrdinalIgnoreCase)))
            {
                return arg;
            }
            if (@object.ForAction.Equals(context.GetPolicy<KnownCustomerActionsPolicy>().AddCustomer, StringComparison.OrdinalIgnoreCase) && @object.ViewName.Equals(context.GetPolicy<KnownCustomerViewsPolicy>().Details, StringComparison.OrdinalIgnoreCase))
            {
                await PopulateDetails(arg, null, isAddAction: true, isEditAction: false, context).ConfigureAwait(continueOnCapturedContext: false);
                return arg;
            }
            bool flag = @object.ForAction.Equals(context.GetPolicy<KnownCustomerActionsPolicy>().EditCustomer, StringComparison.OrdinalIgnoreCase);
            if (!(@object.Entity is Customer) || (!flag && !string.IsNullOrEmpty(@object.ForAction)))
            {
                return arg;
            }
            Customer customer = (Customer)@object.Entity;
            EntityView entityView;
            if (@object.ViewName.Equals(context.GetPolicy<KnownCustomerViewsPolicy>().Master, StringComparison.OrdinalIgnoreCase))
            {
                ViewProperty viewProperty = arg.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("Name", StringComparison.OrdinalIgnoreCase));
                if (viewProperty != null)
                {
                    viewProperty.RawValue = ((customer == null || (string.IsNullOrEmpty(customer.FirstName) && string.IsNullOrEmpty(customer.LastName))) ? string.Empty : ((!string.IsNullOrEmpty(customer.FirstName) && !string.IsNullOrEmpty(customer.LastName)) ? (customer.FirstName + " " + customer.LastName) : ((!string.IsNullOrEmpty(customer.FirstName)) ? customer.FirstName : customer.LastName)));
                    ViewProperty viewProperty2 = arg.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("DisplayName", StringComparison.OrdinalIgnoreCase));
                    if (viewProperty2 != null)
                    {
                        viewProperty2.RawValue = viewProperty.RawValue;
                    }
                    else
                    {
                        arg.Properties.Add(new ViewProperty
                        {
                            Name = "DisplayName",
                            RawValue = viewProperty.RawValue
                        });
                    }
                }
                entityView = new EntityView
                {
                    EntityId = arg.EntityId,
                    Name = context.GetPolicy<KnownCustomerViewsPolicy>().Details
                };
                arg.ChildViews.Add(entityView);
            }
            else
            {
                entityView = arg;
            }
            await PopulateDetails(entityView, customer, isAddAction: false, flag, context).ConfigureAwait(continueOnCapturedContext: false);
            return arg;
        }

        protected virtual async Task PopulateDetails(EntityView view, Customer customer, bool isAddAction, bool isEditAction, CommercePipelineExecutionContext context)
        {
            if (view == null)
            {
                return;
            }
            ValidationPolicy validationPolicy = ValidationPolicy.GetValidationPolicy(context.CommerceContext, typeof(Customer));
            ValidationPolicy detailsValidationPolicy = ValidationPolicy.GetValidationPolicy(context.CommerceContext, typeof(Sitecore.Commerce.Plugin.Customers.CustomerDetailsComponent));
            CustomerPropertiesPolicy propertiesPolicy = context.GetPolicy<CustomerPropertiesPolicy>();
            EntityView details = null;
            if (customer != null && customer.HasComponent<Sitecore.Commerce.Plugin.Customers.CustomerDetailsComponent>())
            {
                details = customer.GetComponent<Sitecore.Commerce.Plugin.Customers.CustomerDetailsComponent>().View.ChildViews.FirstOrDefault((Model v) => v.Name.Equals("Details", StringComparison.OrdinalIgnoreCase)) as EntityView;
            }
            List<string> languages = new List<string>();
            Shop entity = context.CommerceContext.GetEntity<Shop>();
            if (entity != null && entity.Languages.Any())
            {
                languages = entity.Languages.ToList();
            }
            foreach (string propertyName in propertiesPolicy?.DetailsProperties)
            {
                if (isAddAction && propertyName.Equals(propertiesPolicy?.AccountNumber, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                ValidationAttributes validationAttributes = validationPolicy.Models.FirstOrDefault((Model m) => m.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase)) as ValidationAttributes;
                if (propertyName.Equals(propertiesPolicy?.AccountStatus, StringComparison.OrdinalIgnoreCase))
                {
                    KnownCustomersStatusesPolicy statusesPolicy = context.GetPolicy<KnownCustomersStatusesPolicy>();
                    List<Selection> statuses = new List<Selection>();
                    string currentStatus = customer?.AccountStatus ?? string.Empty;
                    if (isAddAction || isEditAction)
                    {
                        PropertyInfo[] properties = typeof(KnownCustomersStatusesPolicy).GetProperties();
                        foreach (PropertyInfo propertyInfo in properties)
                        {
                            if (!propertyInfo.Name.Equals("PolicyId", StringComparison.OrdinalIgnoreCase) && !propertyInfo.Name.Equals("Models", StringComparison.OrdinalIgnoreCase))
                            {
                                string status = propertyInfo.GetValue(statusesPolicy, null) as string;
                                if (!string.IsNullOrEmpty(status))
                                {
                                    LocalizedTerm localizedTerm = await _getLocalizedCustomerStatusPipeline.RunAsync(new LocalizedCustomerStatusArgument(status), context).ConfigureAwait(continueOnCapturedContext: false);
                                    statuses.Add(new Selection
                                    {
                                        DisplayName = localizedTerm?.Value,
                                        Name = status
                                    });
                                }
                            }
                        }
                    }
                    else if (!string.IsNullOrEmpty(currentStatus))
                    {
                        LocalizedTerm localizedTerm2 = await _getLocalizedCustomerStatusPipeline.RunAsync(new LocalizedCustomerStatusArgument(currentStatus), context).ConfigureAwait(continueOnCapturedContext: false);
                        if (!string.IsNullOrEmpty(localizedTerm2?.Value))
                        {
                            currentStatus = localizedTerm2?.Value;
                        }
                    }
                    List<ViewProperty> properties2 = view.Properties;
                    ViewProperty obj = new ViewProperty(new List<Policy>
                {
                    new AvailableSelectionsPolicy(statuses)
                })
                    {
                        Name = propertiesPolicy?.AccountStatus,
                        RawValue = currentStatus,
                        IsReadOnly = (!isAddAction && !isEditAction)
                    };
                    obj.IsRequired = validationAttributes != null && validationAttributes.MinLength > 0;
                    properties2.Add(obj);
                    continue;
                }
                List<ViewProperty> properties3;
                object commercePolicies;
                if (propertyName.Equals(propertiesPolicy?.LoginName, StringComparison.OrdinalIgnoreCase))
                {
                    properties3 = view.Properties;
                    if (isAddAction)
                    {
                        if (validationAttributes != null && validationAttributes.MaxLength > 0)
                        {
                            commercePolicies = new List<Policy>
                        {
                            new MaxLengthPolicy
                            {
                                MaxLengthAllow = validationAttributes.MaxLength
                            }
                        };
                            goto IL_0548;
                        }
                    }
                    commercePolicies = new List<Policy>();
                    goto IL_0548;
                }
                if (propertyName.Equals(propertiesPolicy?.Domain, StringComparison.OrdinalIgnoreCase))
                {
                    view.Properties.Add(new ViewProperty(isAddAction ? new List<Policy>
                {
                    new AvailableSelectionsPolicy((propertiesPolicy?.Domains == null || !propertiesPolicy.Domains.Any() || !(isAddAction || isEditAction)) ? new List<Selection>() : propertiesPolicy?.Domains.Select((string s) => new Selection
                    {
                        DisplayName = s,
                        Name = s
                    }).ToList())
                } : new List<Policy>())
                    {
                        Name = propertiesPolicy?.Domain,
                        RawValue = (customer?.Domain ?? string.Empty),
                        IsReadOnly = !isAddAction,
                        IsRequired = true
                    });
                    continue;
                }
                List<ViewProperty> properties4;
                object commercePolicies2;
                if (propertyName.Equals(propertiesPolicy?.UserName, StringComparison.OrdinalIgnoreCase))
                {
                    if (isAddAction)
                    {
                        continue;
                    }
                    properties4 = view.Properties;
                    if (isAddAction)
                    {
                        if (validationAttributes != null && validationAttributes.MaxLength > 0)
                        {
                            commercePolicies2 = new List<Policy>
                        {
                            new MaxLengthPolicy
                            {
                                MaxLengthAllow = validationAttributes.MaxLength
                            }
                        };
                            goto IL_074e;
                        }
                    }
                    commercePolicies2 = new List<Policy>();
                    goto IL_074e;
                }
                if (propertyName.Equals(propertiesPolicy?.Language, StringComparison.OrdinalIgnoreCase))
                {
                    object obj2 = details?.GetPropertyValue(propertiesPolicy?.Language) ?? (((languages?.Any() ?? false) && isAddAction) ? languages.FirstOrDefault() : string.Empty);
                    List<ViewProperty> properties5 = view.Properties;
                    ViewProperty obj3 = new ViewProperty(new List<Policy>
                {
                    new AvailableSelectionsPolicy((languages != null && languages.Any() && (isAddAction || isEditAction)) ? languages.Select((string s) => new Selection
                    {
                        DisplayName = s,
                        Name = s
                    }).ToList() : new List<Selection>())
                })
                    {
                        Name = propertiesPolicy?.Language,
                        RawValue = (obj2 ?? string.Empty),
                        IsReadOnly = (!isAddAction && !isEditAction)
                    };
                    obj3.IsRequired = validationAttributes != null && validationAttributes.MinLength > 0;
                    properties5.Add(obj3);
                    continue;
                }
                PropertyInfo property = typeof(Customer).GetProperty(propertyName);
                List<ViewProperty> properties6;
                object commercePolicies3;
                if (property != null)
                {
                    properties6 = view.Properties;
                    if (isAddAction || isEditAction)
                    {
                        if (validationAttributes != null && validationAttributes.MaxLength > 0)
                        {
                            commercePolicies3 = new List<Policy>
                        {
                            new MaxLengthPolicy
                            {
                                MaxLengthAllow = validationAttributes.MaxLength
                            }
                        };
                            goto IL_098c;
                        }
                    }
                    commercePolicies3 = new List<Policy>();
                    goto IL_098c;
                }
                object obj4 = details?.GetPropertyValue(propertyName);
                ValidationAttributes validationAttributes2 = detailsValidationPolicy.Models.FirstOrDefault((Model m) => m.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase)) as ValidationAttributes;
                view.Properties.Add(new ViewProperty(((isAddAction || isEditAction) && validationAttributes2 != null && validationAttributes2.MaxLength > 0) ? new List<Policy>
            {
                new MaxLengthPolicy
                {
                    MaxLengthAllow = validationAttributes2.MaxLength
                }
            } : new List<Policy>())
                {
                    Name = propertyName,
                    RawValue = (obj4 ?? string.Empty),
                    IsReadOnly = (!isAddAction && !isEditAction),
                    IsRequired = (validationAttributes2 != null && validationAttributes2.MinLength > 0)
                });
                continue;
            IL_098c:
                ViewProperty obj5 = new ViewProperty((List<Policy>)commercePolicies3)
                {
                    Name = propertyName,
                    RawValue = ((customer == null) ? string.Empty : property.GetValue(customer, null)),
                    IsReadOnly = ((!isAddAction && !isEditAction) || propertyName.Equals(propertiesPolicy?.AccountNumber, StringComparison.OrdinalIgnoreCase))
                };
                obj5.IsRequired = validationAttributes != null && validationAttributes.MinLength > 0;
                properties6.Add(obj5);
                continue;
            IL_0548:
                properties3.Add(new ViewProperty((List<Policy>)commercePolicies)
                {
                    Name = propertiesPolicy?.LoginName,
                    RawValue = (customer?.LoginName ?? string.Empty),
                    IsReadOnly = !isAddAction,
                    IsRequired = true
                });
                continue;
            IL_074e:
                properties4.Add(new ViewProperty((List<Policy>)commercePolicies2)
                {
                    Name = propertiesPolicy?.UserName,
                    RawValue = (customer?.UserName ?? string.Empty),
                    IsReadOnly = !isAddAction,
                    IsRequired = true
                });
            }

            //Adding custom properties to customer

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "DOB",
                RawValue = details?.GetPropertyValue("DOB"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "ReceiveEchoparkCommunications",
                RawValue = details?.GetPropertyValue("ReceiveEchoparkCommunications"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PreferredVehicleMake",
                RawValue = details?.GetPropertyValue("PreferredVehicleMake"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PreferredVehicleModel",
                RawValue = details?.GetPropertyValue("PreferredVehicleModel"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CurrentVehicleMake",
                RawValue = details?.GetPropertyValue("CurrentVehicleMake"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CurrentVehicleModel",
                RawValue = details?.GetPropertyValue("CurrentVehicleModel"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GeneralEmailAlert",
                RawValue = details?.GetPropertyValue("GeneralEmailAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GeneralSMSAlert",
                RawValue = details?.GetPropertyValue("GeneralSMSAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PriceDropEmailAlert",
                RawValue = details?.GetPropertyValue("PriceDropEmailAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "PriceDropSMSAlert",
                RawValue = details?.GetPropertyValue("PriceDropSMSAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CarSoldEmailAlert",
                RawValue = details?.GetPropertyValue("CarSoldEmailAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "CarSoldSMSAlert",
                RawValue = details?.GetPropertyValue("CarSoldSMSAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "DealerCommunicationAlert",
                RawValue = details?.GetPropertyValue("DealerCommunicationAlert"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
            });
            List<string> list = new List<string>();
            if (customer?.Tags != null && customer.Tags.Any())
            {
                list.AddRange((customer?.Tags.Where((Tag t) => !t.Excluded)).Select((Tag tag) => tag.Name));
            }
            if (!isAddAction)
            {
                view.Properties.Add(new ViewProperty(new List<Policy>())
                {
                    Name = "IncludedTags",
                    RawValue = list.ToArray(),
                    IsReadOnly = (!isAddAction && !isEditAction),
                    IsRequired = false,
                    UiType = (isEditAction ? "Tags" : "List"),
                    OriginalType = "List"
                });
            }
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "SSN",
                RawValue = details?.GetPropertyValue("SSN"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GetSMSCommunications",
                RawValue = details?.GetPropertyValue("GetSMSCommunications"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });
            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "GetEmailCommunications",
                RawValue = details?.GetPropertyValue("GetEmailCommunications"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.Boolean)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "VIN",
                RawValue = details?.GetPropertyValue("VIN"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });


            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Make",
                RawValue = details?.GetPropertyValue("Make"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Model",
                RawValue = details?.GetPropertyValue("Model"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Year",
                RawValue = details?.GetPropertyValue("Year"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Trim",
                RawValue = details?.GetPropertyValue("Trim"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "OfferValue",
                RawValue = details?.GetPropertyValue("OferValue"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "OfferExpiration",
                RawValue = details?.GetPropertyValue("OfferExpiration"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });

            view.Properties.Add(new ViewProperty(new List<Policy>())
            {
                Name = "Mileage",
                RawValue = details?.GetPropertyValue("Mileage"),
                IsReadOnly = (!isAddAction && !isEditAction),
                IsRequired = false,
                OriginalType = nameof(System.String)
            });



        }
    }
}
