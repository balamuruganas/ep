﻿namespace Echopark.Feature.Accounts.Models
{
    public class AlertPreferenceInputModel
    {
        public string PhoneNumber { get; set; }
        public KeyValue KeyValue { get; set; }
    }
    public class KeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}