﻿using System;

namespace Echopark.Feature.Accounts.Models
{
    public class EmailNotifyArguments
    {
        public Event Event { get; set; }
        public EmailNotifyArguments()
        {
            Event = new Event();
        }

        public string EventCategory { get; set; }
        public string EventSource { get; set; }
        public string EventType { get; set; }
        public DateTime Time { get; set; }
        public string EventId { get; set; }
        
    }
    public class Event
    {
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
      
        public string Link { get; set; }
    }
    public enum EventType
    {
        None,
        ForgotPassword,
        CreateAccount
    }
}