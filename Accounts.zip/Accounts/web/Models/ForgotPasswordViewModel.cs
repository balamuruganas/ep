﻿using Echopark.Foundation.Common.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Echopark.Feature.Accounts.Models
{
    public class ForgotPasswordViewModel
    {
        
        public ForgotPasswordAndEmailSent forgotPasswordAndEmailSent { get; set; }
        public static string EmailNotFound => SitecoreUtility.GetDictionaryValue(Templates.Dictionary.ForgotPassword.ValidationMessages.EmailNotFound);
        public static string InvalidEmailAddressErrorMessage => SitecoreUtility.GetDictionaryValue(Templates.Dictionary.ForgotPassword.ValidationMessages.InvalidEmailAddress);
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessageResourceName = nameof(InvalidEmailAddressErrorMessage), ErrorMessageResourceType = typeof(ForgotPasswordViewModel))]
        public string EmailId
        {
            get; set;
        }
      
    }
}