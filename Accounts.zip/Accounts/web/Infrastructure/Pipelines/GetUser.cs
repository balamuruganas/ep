﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Echopark.Feature.Accounts.Infrastructure.Pipelines
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
using Echopark.Foundation.Common.Utilities;
using Echopark.Foundation.Common;
using System.Reflection;
    using Sitecore.Commerce.Engine;
    using Sitecore.Commerce.Engine.Connect.Pipelines;
    using Sitecore.Commerce.Entities;
    using Sitecore.Commerce.Entities.Customers;
    using Sitecore.Commerce.EntityViews;
    using Sitecore.Commerce.Pipelines;
    using Sitecore.Commerce.Services.Customers;
    using Sitecore.Diagnostics;

    public class GetUser : PipelineProcessor
    {
        public IEntityFactory EntityFactory { get; set; }

        public GetUser(IEntityFactory entityFactory)
        {
            Assert.ArgumentNotNull(entityFactory, "entityFactory");
            EntityFactory = entityFactory;
        }

        public override void Process(ServicePipelineArgs args)
        {
            PipelineUtility.ValidateArguments<GetUserRequest, GetUserResult>(args, out var request, out var result);
            Assert.IsFalse(string.IsNullOrEmpty(request.UserName) && string.IsNullOrEmpty(request.ExternalId), "at least one request.UserName or request.ExternalId needs to be set");
            Container container = GetContainer(request.Shop.Name, string.Empty, request.UserName, "", args.Request.CurrencyCode);
            string entityId = (string.IsNullOrEmpty(request.ExternalId) ? ("Entity-Customer-" + request.UserName) : request.ExternalId);
            EntityView entityView = GetEntityView(container, entityId, string.Empty, "Details", string.Empty, result);
            if (result.Success)
            {
                result.CommerceUser = TranslateViewToCommerceUser(entityView);
                base.Process(args);
            }
        }

        protected virtual CommerceUser TranslateViewToCommerceUser(EntityView view)
        {
            CommerceUser commerceUser = EntityFactory.Create<CommerceUser>("CommerceUser");
            commerceUser.ExternalId = "Entity-Customer-" + view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("AccountNumber", StringComparison.OrdinalIgnoreCase)).Value;
            commerceUser.FirstName = view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("FirstName", StringComparison.OrdinalIgnoreCase)).Value;
            commerceUser.LastName = view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("LastName", StringComparison.OrdinalIgnoreCase)).Value;
            commerceUser.UserName = view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("UserName", StringComparison.OrdinalIgnoreCase)).Value;
            commerceUser.Email = view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("Email", StringComparison.OrdinalIgnoreCase)).Value;

            commerceUser.SetPropertyValue("Phone", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("PhoneNumber", StringComparison.OrdinalIgnoreCase)).Value);
            try
            {
                commerceUser.SetPropertyValue("DOB", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("DOB", StringComparison.OrdinalIgnoreCase)).Value);
                commerceUser.SetPropertyValue("ReceiveEchoparkCommunications", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("ReceiveEchoparkCommunications", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("PreferredVehicleMake", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("PreferredVehicleMake", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("PreferredVehicleModel", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("PreferredVehicleModel", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("CurrentVehicleMake", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("CurrentVehicleMake", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("CurrentVehicleModel", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("CurrentVehicleModel", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("GeneralEmailAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("GeneralEmailAlert", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("GeneralSMSAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("GeneralSMSAlert", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("PriceDropEmailAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("PriceDropEmailAlert", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("PriceDropSMSAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("PriceDropSMSAlert", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("CarSoldEmailAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("CarSoldEmailAlert", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("CarSoldSMSAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("CarSoldSMSAlert", StringComparison.OrdinalIgnoreCase))?.Value);
                commerceUser.SetPropertyValue("DealerCommunicationAlert", view.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("DealerCommunicationAlert", StringComparison.OrdinalIgnoreCase))?.Value);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }

            Assert.IsNotNullOrEmpty(commerceUser.ExternalId, "commerceUser.ExternalId");
            if (commerceUser.Customers == null || commerceUser.Customers.Count == 0)
            {
                List<string> list2 = (commerceUser.Customers = new List<string> { commerceUser.ExternalId });
            }
            return commerceUser;
        }
    }
}
