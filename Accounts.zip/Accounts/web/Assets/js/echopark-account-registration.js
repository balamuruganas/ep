﻿$(document).ready(function () {
    $("#RegisterForm .PhoneNumberFormat").on('blur', function () {
        if ($(this).next().hasClass("field-validation-error")) {
            $('#RegisterForm').valid();
        }
    });
    $("#txtRegFirstName,#txtRegLastName").keypress(function (key) {
        var regNameLength = parseInt($(this).attr("data-val-length-max") || 30);
        if ($(this).val().length >= regNameLength) {
            return false;
        }
    });
    $("#reg_enter_password,#reg_confirm_password").keypress(function (key) {
        var regPasswordLength = parseInt($(this).attr("data-val-length-max") || 16);
        if ($(this).val().length >= regPasswordLength) {
            return false;
        }
    });
});

function OnBeginCreateAccount() {
    DisableForm();
    
    
}
function isOptSmsChecked() {
    $("#RegisterForm").valid();
    var isOptSmsChecked = $("#sms-checkbox").is(":checked");
    if (isOptSmsChecked) {
        if ($("#txtRegPhoneNumber").val().length === 0) {
            $('.phonenumber_error').html($("#PhonenumberRequiredMsg").val())
            $('.phonenumber_error').show();
            return false;
        }
    }
    $(".password-info").show();
    GaTrack_CreateAccountCTA(window.location.href);
    GaTrack_RegistrationFieldError();
    return true;
}

function GaTrack_RegistrationFieldError() {
    let RgstErrorFieldName = [];
    if ($("#txtRegFirstName").val()=="") {
        RgstErrorFieldName.push("First Name");
    }
    if ($("#txtRegLastName").val()=="") {
        RgstErrorFieldName.push("Last Name");
    }
    if ($("#useremailid").val()=="") {
        RgstErrorFieldName.push("Email");
    }
    if ($("#reg_enter_password").val()=="") {
        RgstErrorFieldName.push("Password");
    }
    if ($("#reg_confirm_password").val()=="") {
        RgstErrorFieldName.push("Confirm Password");
    }
    if (RgstErrorFieldName.length) {
        dataLayer.push({
            "error": RgstErrorFieldName.toString()
        });
    }
}
function GaTrack_CreateAccountCTA(link) {
    dataLayer.push({
        "link": link
    });
    return true;
}

 function GaTrack_ReceiveEchoParkCommn(isChecked) {
    dataLayer.push({
        "checkbox": isChecked
    });
    return true;
}
$(document).on("change", "#email-checkbox", function () {
    if ($("#email-checkbox").is(":checked")) {
        GaTrack_ReceiveEchoParkCommn(1);
    }
    else {
        GaTrack_ReceiveEchoParkCommn(0);
    }
});


function OnSuccessCreateAccount(data) {
    EnableForm();
   
    if (data != undefined) {

        if (data.HasErrors != undefined && data.HasErrors) {
            var customError = data.Errors.length > 1 ? data.Errors[1] : data.Errors[0];
            $("#pRegistationErrorMessage").html(customError);
        }
        else if (data.Success != undefined && data.Success) {
            $(".create_account").removeClass("show-createAccount").addClass("accountCreated-content");
            $(".accountCreated-content").show();
            var defaultPageAfterLogin = $("#accountCreatedDefualtPageLink").prop("href") || "/";
            $(".user_profile .guest-user").prop({ "href": defaultPageAfterLogin, "rel": "", "class": "registered-user" });
        }
        else {
            console.log(data);
        }
    }
}

function OnFailureCreateAccount(data) {
    EnableForm();
}

function ClearResult() {

}