﻿using Sitecore.Commerce.XA.Feature.Account.Models.InputModels;

namespace Echopark.Feature.Accounts.Models
{
    public class RegisterUserModel : RegistrationUserInputModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
    }
}