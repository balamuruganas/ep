﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data;

namespace Echopark.Feature.Accounts
{
    public class Templates
    {
        public struct ForgotPasswordAndEmailSent
        {
            public static readonly ID ID = new ID("{DAAF124E-5059-4991-BAE1-BC92C34B279F}");
            public struct Fields
            {
                public static readonly ID ForgotPasswrdTitle = new ID("{E9625480-0F60-4361-B604-56F1A956AFE8}");
                public static readonly ID ForgotPassIntroCopy = new ID("{814BA54F-DDEF-402B-8792-DF5E0CFA4C7E}");
                public static readonly ID EmailFieldPlaceHolder = new ID("{2D3FB66B-1570-4009-B573-30D994432CA8}");
                public static readonly ID SendCTAText = new ID("{E076B4F0-3498-4B85-91B5-142E06271D6E}");
                public static readonly ID RememberPassword = new ID("{C801933D-90F4-4204-A36C-973EA359B267}");
                public static readonly ID ForgotPasswordSignInCTA = new ID("{5D368482-9451-45BD-98D3-BBFFDCC43E49}");

                public static readonly ID EmailSentTitle = new ID("{710E7C61-CD20-4F1A-934A-5BB4F583E529}");
                public static readonly ID EmailSentIntroCopy = new ID("{4B01DE8C-7672-413D-81DE-E6F137A8D5A7}");
                public static readonly ID EmailSentSignInCTA = new ID("{87FB153B-2E7E-4EF3-9F28-54B0D07A6BA9}");
                public static readonly ID NoEmailReceive = new ID("{AF3528D5-4BB9-4627-94DC-B795C2AAABEE}");
                public static readonly ID ResentCTAText = new ID("{8781D772-3784-4F04-ABF8-5D85926F2C92}");
                public static readonly ID ResentHeaderText = new ID("{27CB836C-2FBE-480D-8598-6BCF58B3C4E8}");
                public static readonly ID DictInvali = new ID("{C2B92CD6-2DA7-4BF2-991B-D038D8D1FD96}");

            }

        }

        public struct Dictionary
        {
            public struct ForgotPassword
            {
                public struct ValidationMessages
                {
                    public static string InvalidEmailAddress => "{C2B92CD6-2DA7-4BF2-991B-D038D8D1FD96}";
                    public static string EmailNotFound => "{16879751-3759-4F92-9936-268A4BDCC716}";

                }
            }
            public struct Labels
            {
                public static string Email = "{10D32552-3D03-4A74-9B65-2D13B42B34D2}";

            }

        }
        public struct ChangePasswordFormDatasource
        {
            public static readonly ID ID = new ID("{5520FF79-CB6D-4B3D-8CF5-CE39E564E625}");

            public struct Fields
            {
                public static readonly ID SectionImage = new ID("{4853C49F-5E46-4E46-84BE-E71218D8FF7E}");
                public static readonly ID Title = new ID("{01897668-014B-4936-BDAA-BFD2467AD145}");
                public static readonly ID Description = new ID("{974C5002-92AF-435B-9F6A-88960B80C3D8}");
                public static readonly ID NewPasswordLabel = new ID("{C3D630A7-6E16-42AD-B182-9303732BE291}");
                public static readonly ID NewPasswordPlaceholder = new ID("{C2212961-4374-43CE-9996-C0A11180D4C1}");
                public static readonly ID ConfirmPasswordLabel = new ID("{1EF9C7F9-7FD3-4B94-A718-CDA24716E44C}");
                public static readonly ID ConfirmPasswordPlaceholder = new ID("{E192B605-9FA1-41AD-B0DE-57F6F4DB585D}");
                public static readonly ID MustContainLabel = new ID("{7D2154DB-D720-4E21-84F9-FA77B4C8A2BE}");
                public static readonly ID Atleast6charactersLabel = new ID("{C3BC4016-C253-4807-B6AE-72E3C6DB61F8}");
                public static readonly ID Atleast1uppercaseletterLabel = new ID("{A354EE4E-4F93-40C3-907C-BFC3A5BFF0FE}");
                public static readonly ID Atleast1lowercaseletterLabel = new ID("{47340F9A-1573-4E92-A64D-E5FA4613A009}");
                public static readonly ID Atleast1numberLabel = new ID("{32593DAE-E433-499D-BB5F-810A7FCD9629}");
                public static readonly ID NewPasswordValidationMessage = new ID("{E0A3F616-73C4-4B40-B076-25D76EDB08DF}");
                public static readonly ID PasswordsMismatchValidationMessage = new ID("{1CA10C1B-EFAB-4E99-8BB6-3A4EC29FF946}");
                public static readonly ID CTALabel = new ID("{5A0AF404-004A-4AF2-AA45-8E2747C71350}");
                public static readonly ID TokenExpiredMessage = new ID("{E7CCA29A-EDBE-47AC-8C60-6DC97718A4D9}");
            }
        }

        public struct PasswordChangedSection
        {
            public static readonly ID ID = new ID("{5105C1BF-E7F5-4804-BF69-814A2A78520C}");

            public struct Fields
            {
                public static readonly ID Content = new ID("{D23470B8-A3B9-4585-A10C-C53507D141FD}");
            }
        }
        public struct ProfileView
        {
            public static ID ID = new ID("{657ECAF8-E54E-482C-BE4E-468041994988}");
            public struct Fields
            {
                public static ID ProfileHeaderText = new ID("{DD0D9940-A96C-4EFB-A1E5-A62EC67E4442}");
                public static ID SignOutText = new ID("{1EA420C9-923D-4FB0-BD45-6721523F332C}");
                public static ID SignOutLink = new ID("{94006238-4EE5-419B-96A8-DF19E50169CA}");
            }
        }

        public struct Profile
        {
            public static string NoDatasourceFound = "{CB5A504B-99B2-43AF-BD02-CAD931E6017C}";
        }
        public struct ProfileInformation
        {
            public static ID ID = new ID("{2AAF590C-D77E-4364-BB2A-09561006EDAC}");
            public struct Fields
            {
                public static ID ProfileInformationHeader = new ID("{FED6CABE-E18E-4C31-8189-3B240944174D}");
                public static ID EmailLabel = new ID("{E7CDFC0E-E00B-4C50-B593-19D9F27B666D}");
                public static ID EmailTooltipText = new ID("{D0FD5CD3-5D0C-4480-9DE8-393E8EDE685C}");
                public static ID NameLabel = new ID("{10EB36C4-15DF-4F6A-BC0D-18A9FBE035D5}");
                public static ID FirstNameLabel = new ID("{8D9928CA-3DFF-473C-BE69-FEE6BAD947DF}");
                public static ID FirstNameMissingMessage = new ID("{0F558B35-EBF9-4D97-A988-6E832E55B971}");
                public static ID FirstNameLengthMessage = new ID("{95433927-930E-45DB-85C6-6DA93F17C7BC}");
                public static ID FirstNameHintText = new ID("{85E836CE-365C-4829-8E43-B1E8370C310D}");
                public static ID LastNameLabel = new ID("{45517C5D-CC1E-4E68-AAC0-B1F5EF1984F6}");
                public static ID LastNameMissingMessage = new ID("{3F442AFC-6989-45B6-B188-EFC0D84B3949}");
                public static ID LastNameLengthMessage = new ID("{E77CEE16-FE7B-4B29-9F46-3A0D77ED17C9}");
                public static ID LastNameHintText = new ID("{E17479D3-2DB1-407B-87C0-D007CA0584EE}");
                public static ID PhoneNumberLabel = new ID("{857372F8-C2F9-48E3-88EC-110ED0904E1D}");
                public static ID PhoneNumberHintText = new ID("{4F1DF1BC-B8F7-4FA8-809E-2F69249E8D5A}");
                public static ID PhoneNumberLengthMessage = new ID("{3EBF29FE-E087-41D4-A0E0-4E86434DC609}");
                public static ID PhoneNumberInvalidMessage = new ID("{9B40E64D-3735-4076-A5BC-E494FC8D1C23}");
                public static ID PhoneNumberMissingMessage = new ID("{1BAB9193-F30B-4DF3-B0EE-517E7DFFE02E}");
                public static ID BirthdayLabel = new ID("{AA89D23A-8EB8-4B00-A561-CE3C90851CE8}");
                public static ID BirthDateNoProvidedLabel = new ID("{E9083822-C9E1-41A7-A227-4DA6D2641637}");
                public static ID BirthDateLabel = new ID("{1827F987-CF15-40E1-B94B-F8B06F0D15B1}");
                public static ID EditLinkLabel = new ID("{487F715A-03D2-44F1-8838-2DEFF2BC0F55}");
                public static ID SaveButtonLabel = new ID("{FC15F0BF-9C99-4072-83CA-78560FEA89BE}");
                public static ID CancelButtonLabel = new ID("{B272291A-55EE-4AC6-92FE-F9A9C74F8E90}");
                public static ID BirthDateMissingMessage = new ID("{5E0481BA-902B-410A-AB82-7AE9F509A607}");
                public static ID BirthDateInvalidMessage = new ID("{5D677C45-4065-4425-85A2-3129EF08EF9C}");
            }
        }
        public struct ProfileChangePassword
        {
            public static ID ID = new ID("{A1BCCF01-C710-43E6-8F6D-99A9F8BB5940}");
            public struct Fields
            {
                public static ID SecurityLabel = new ID("{B5F3D1F0-47F4-48EA-B8DC-F7D45DEC3F9B}");
                public static ID PasswordLabel = new ID("{2BA0D869-7607-4E7B-96B4-63D2BA3108C7}");
                public static ID PasswordMask = new ID("{70182B8E-4461-4369-B0EF-9E979B5EAE04}");
                public static ID CurrentPasswordLabel = new ID("{E8D12BD9-0A13-46CE-85E6-D21D3831C6E4}");
                public static ID CurrentPasswordMissingMessage = new ID("{13111B2E-6DE6-4225-B626-240F6C9478F0}");
                public static ID CurrentPasswordLengthMessge = new ID("{147F7902-80F8-44C5-ADA6-7B37EB912B63}");
                public static ID CurrentPasswordInvalidMessage = new ID("{0CBEEF89-795E-4416-BDEC-7C6ABEFDDC62}");
                public static ID NewPasswordLabel = new ID("{60EB9A68-C593-473B-BF61-17747E1BE438}");
                public static ID NewPasswordMissingMesage = new ID("{2F1788C8-ED9B-4688-8F02-0BC9A68D20E5}");
                public static ID NewPasswordLengthMessage = new ID("{DEC0ADFF-3349-4E5E-8B21-319C5335E4B6}");
                public static ID NewPasswordHintText = new ID("{0DCC67D9-416A-4DA9-8938-3092D16503FF}");
                public static ID SaveButtonLabel = new ID("{AA976A7B-57F7-4CBF-A7AD-C669B14569C8}");
                public static ID ChangeButtonLabel = new ID("{47DB4286-D37A-43C6-AB23-6817316476DB}");
                public static ID CancelButtonLabel = new ID("{C4C16BEE-1787-45C6-85EF-E7727991289D}");
                public static ID NewPasswordRegexValidationMessage = new ID("{BE4A7A5F-F5FF-462F-BAAC-AFBE24B3BEAA}");
                public static ID PasswordInfo = new ID("{C21FB454-41D2-4105-A601-1D128B06B1E7}");
                public static ID SamePasswordErrorMessage = new ID("{832338E4-BB90-417C-8AA1-9AC3C11DDE44}");
            }
        }
        public struct ProfileCarInformation
        {
            public static ID ID = new ID("{815A8E00-8296-4717-A397-7010CD40BBDB}");
            public struct Fields
            {
                public static ID CarInformationHeader = new ID("{0B503518-A12D-4763-B0E9-9C03C8A704EB}");
                public static ID CurrentCarTitle = new ID("{BB234D00-B32B-4DA2-84AA-9EF2CA402198}");
                public static ID CurrentCarDescription = new ID("{C8403237-E51A-4BA1-B38E-9CC77C31A11A}");
                public static ID CurrentCarMakeLabel = new ID("{CE9EE04E-54B8-4FD3-A282-07C9D4223AE4}");
                public static ID CurrentCarModelLabel = new ID("{66BF8235-15B8-4467-A8D0-DB896D432AB1}");
                public static ID CurrentCarDropDownMakeLabel = new ID("{134D4907-7516-43F3-8720-040A57FE5FDE}");
                public static ID CurrentCarDropDownModelLabel = new ID("{0C4DDFCC-7760-4CD0-868E-9DB5DFAC1D70}");
                public static ID CurrentCarMakeMissingMessage = new ID("{83FEB00F-5BD1-410B-855D-7342F6EC570D}");
                public static ID CurrentCarModelMissingMessage = new ID("{C92923F3-31F0-48E3-82FF-A9281620B8C3}");
                public static ID PreferredCarTitle = new ID("{85B6EEEB-776E-412B-9576-CDD638F295CC}");
                public static ID PreferredCarDescription = new ID("{7DB1ACC1-EC90-418A-9579-84BC4BC2053A}");
                public static ID PreferredCarMakeLabel = new ID("{3FD8D69C-131C-45F4-B35A-DBB785EFFE34}");
                public static ID PreferredCarModelLabel = new ID("{58F4318D-D8B0-4E2B-AEDA-4B378B6ACCDD}");
                public static ID PreferredCarDropDownMakeLabel = new ID("{49FF9C39-7DD0-4A7E-8A39-E6ACBC363B4A}");
                public static ID PreferredCarDropDownModelLabel = new ID("{FD60C144-E719-4D58-9F11-759872D6B930}");
                public static ID PreferredCarMakeMissingMessage = new ID("{80674726-70B5-415E-87D4-2DE5AE6674DA}");
                public static ID PreferredCarModelMissingMessage = new ID("{0BC3286D-60CB-4626-B567-638FDAADD245}");
                public static ID EditLinkLabel = new ID("{AAADE2CB-07FD-4CAD-9883-8A60FBC62BCB}");
                public static ID SaveButtonLabel = new ID("{65EF7BB7-C57A-489C-83A8-0B74A7F97DC2}");
                public static ID CancelButtonLabel = new ID("{9D57DC42-198E-41D0-ADE2-0F8B89031D1B}");
            }
        }
        public struct ProfileAlterPreferences
        {
            public static ID ID = new ID("{AE992891-5ABA-425B-9196-1F774391C747}");
            public struct Fields
            {
                public static ID AlertPreferenceHeader = new ID("{67B2F3B9-D956-4626-A6FC-8D2E0D6F160D}");
                public static ID GeneralCommunicationTitle = new ID("{8F1B0CD0-BE7E-4B5E-939A-8DCFEE4216E7}");
                public static ID GeneralCommunicationDescription = new ID("{B538DF95-B81B-4F78-9138-7B3D384744A8}");
                public static ID GeneralCommunicationEmailLabel = new ID("{406FF5FA-37D2-47CB-8668-A337BFC3A05C}");
                public static ID GeneralCommunicationSMSLabel = new ID("{FAA3B54A-FBAF-456D-84C3-115B5B9AE2E7}");
                public static ID PriceDropAlertTitle = new ID("{6A844021-9E98-4857-9254-BD9548EE61F3}");
                public static ID PriceDropAlertDescription = new ID("{E77728C4-AAD9-4629-8026-D75F85CAF5C2}");
                public static ID PriceDropAlertEmailLabel = new ID("{277D0F8F-AA63-459F-9DCE-9FAD4D34DF7C}");
                public static ID PriceDropAlertSMSLabel = new ID("{D32BDAFE-8C96-4ADC-98A7-D1B81F6420B1}");
                public static ID CarSoldAlertTitle = new ID("{81AE9089-4802-4C0A-B88D-02FCB3653BF4}");
                public static ID CarSoldAlertDescription = new ID("{DF76B0E3-E29E-4271-85D6-6B847507CBAB}");
                public static ID CarSoldAlertEmailLabel = new ID("{5C5B31F8-976A-4DA8-8A6D-58FCC3E1E84D}");
                public static ID CarSoldAlertSMSLabel = new ID("{18B1B5BD-867C-493F-A372-261C06647F48}");
                public static ID DealershipCommunicationAlertTitle = new ID("{40E459EC-EBD5-4FF8-A74D-AD421C442311}");
                public static ID DealershipCommunicationAlertDescription = new ID("{09D69AFD-DC56-4F20-987C-95C68A533B35}");
                public static ID DealershipCommunicationAlertEmailLabel = new ID("{C0CE6601-670B-4FFA-A3E5-6A13C5FFBFE6}");
                public static ID DealershipCommunicationAlertSMSLabel = new ID("{83C7E160-5455-4FAA-BDF8-A7F2864738F9}");
                public static ID DealershipCommunicationAlertPhoneLabel = new ID("{52CD0D8D-FCFE-42DE-906B-B7D91EA16B07}");
                public static ID PhoneNumberLabel = new ID("{FE0CDF94-4656-4BA5-836A-563A396DBA21}");
                public static ID PhoneNumberLengthMessage = new ID("{347FA60A-3C7C-4A89-9835-A6540FEDE239}");
                public static ID PhoneNumberInvalidMessage = new ID("{47B4EDEF-B288-4064-B8CF-4CC2E7053DC0}");
                public static ID PhoneNumberMissingMessage = new ID("{00B5C4DF-B331-4320-B972-A7914BE8AFD0}");
                public static ID SaveButtonLabel = new ID("{950B4666-5968-4B19-8619-323A35BC6D2B}");
                public static ID CancelButtonLabel = new ID("{7F0B04BD-7BD2-46F9-8592-6B939445889E}");
                public static ID PhoneNumberDialogMessage = new ID("{9B4E568C-E093-4BF3-AA5F-8186E6E1EDBE}");
            }
        }
    }
}