﻿using Echopark.Feature.Accounts.Models;
using Echopark.Foundation.Accounts.Models;
using Echopark.Foundation.Accounts.Models.Checkout;
using Echopark.Foundation.Common;
using Echopark.Foundation.Common.Utilities;
using Sitecore.Commerce.Entities.Customers;
using Sitecore.Commerce.XA.Feature.Account.Controllers;
using Sitecore.Commerce.XA.Feature.Account.Models.InputModels;
using Sitecore.Commerce.XA.Feature.Account.Models.JsonResults;
using Sitecore.Commerce.XA.Feature.Account.Repositories;
using Sitecore.Commerce.XA.Foundation.Common;
using Sitecore.Commerce.XA.Foundation.Common.Attributes;
using Sitecore.Commerce.XA.Foundation.Common.Context;
using Sitecore.Commerce.XA.Foundation.Common.Models.JsonResults;
using Sitecore.Commerce.XA.Foundation.Connect;
using Sitecore.Commerce.XA.Foundation.Connect.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using System.Web.SessionState;
using System.Web.UI;
using EFA = Echopark.Foundation.Accounts;

namespace Echopark.Feature.Accounts.Controllers
{
    [Authorize]
    public class ProfileController : AccountProfileController
    {
        public ProfileController(Sitecore.Commerce.XA.Feature.Account.Repositories.IProfileViewRepository profileViewRepository,
            IProfileEditorRepository profileEditorRepository, IAccountManager accountManager, IStorefrontContext storefrontContext, IContext sitecoreContext,
            Repositories.IProfileViewRepository echoparkUserProfileViewRepository, IVisitorContext visitorContext, IChangePasswordRepository changePasswordRepository)
            : base(profileViewRepository, profileEditorRepository, accountManager, storefrontContext, sitecoreContext)
        {
            this.EchoparkProfileViewRepository = echoparkUserProfileViewRepository;
            this.VisitorContext = visitorContext;
            ChangePasswordRepository = changePasswordRepository;
        }

        public Repositories.IProfileViewRepository EchoparkProfileViewRepository { get; set; }
        public IChangePasswordRepository ChangePasswordRepository { get; set; }
        public IVisitorContext VisitorContext { get; }

        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult GetProfileView()
        {
            ProfileViewRenderingViewModel model = EchoparkProfileViewRepository.GetProfileViewModel(base.Rendering, null);
            return View("~/Views/Echopark/Profile/ProfileView.cshtml", model);
        }


        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult AlertPreferencesEditor()
        {
            AlertPreferenceModel model = EchoparkProfileViewRepository.GetAlertPreferencesViewModel(base.Rendering, null);
            return View("~/Views/Echopark/Profile/AlertPreferences.cshtml", model);
        }

        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult CarInformationEditor()
        {
            CarInformationModel model = EchoparkProfileViewRepository.GetCarInformationViewModel(base.Rendering, null);

            var makeList = new List<SelectListItem>()
                {
                    new SelectListItem(){ Text="BMW",Value="BMW"},
                    new SelectListItem(){ Text="FORD",Value="FORD"},
                    new SelectListItem(){ Text="Honda",Value="Honda"}
                };
            var modelList = new List<SelectListItem>()
                {
                    new SelectListItem(){ Text="7-series",Value="7-series"},
                    new SelectListItem(){ Text="8-series",Value="8-series"},
                    new SelectListItem(){ Text="Econoline",Value="Econoline"},
                    new SelectListItem(){ Text="X2",Value="X2"},
                    new SelectListItem(){ Text="Transit Connect",Value="Transit Connect"},
                    new SelectListItem(){ Text="Odyssey",Value="Odyssey"}
                };
            model.CurrentCarMakeList.AddRange(makeList);
            model.CurrentCarModelList.AddRange(modelList);
            model.PreferredCarMakeList.AddRange(makeList);
            model.PreferredCarModelList.AddRange(modelList);

            return View("~/Views/Echopark/Profile/CarInformation.cshtml", model);
        }

        [HttpPost]
        [Authorize]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult UpdatePassword(ChangePasswordEditorModel inputModel)
        {
            try
            {
                ChangePasswordBaseJsonResult result = new ChangePasswordBaseJsonResult(this.StorefrontContext, this.SitecoreContext);
                this.ValidateModel(result);

                if (!System.Web.Security.Membership.ValidateUser(VisitorContext.UserName, inputModel.CurrentPassword))
                {
                    List<string> errors = new List<string>() { ChangePasswordEditorModel.CurrentPasswordInvalidMessge };
                    result.SetErrors(errors);
                    return Json(result);
                }
                if (inputModel.CurrentPassword.Equals(inputModel.NewPassword))
                {
                    List<string> errors = new List<string>() { ChangePasswordEditorModel.SamePasswordErrorMessage };
                    result.SetErrors(errors);
                    return Json(result);
                }

                if (!result.HasErrors)
                {
                    var response = this.AccountManager.ChangeUserPassword(this.VisitorContext, inputModel.CurrentPassword, inputModel.NewPassword);
                    result = new ChangePasswordBaseJsonResult(this.StorefrontContext, this.SitecoreContext);
                    if (response.ServiceProviderResult.Success)
                    {
                        result.Initialize(this.VisitorContext.UserName);
                        result.SetInfo(base.StorefrontContext.GetSystemMessage("Change Password Success"));
                    }
                }
                result.Data = EchoparkProfileViewRepository.GetUserProperties();

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Json(new ChangePasswordBaseJsonResult(base.StorefrontContext, base.SitecoreContext), JsonRequestBehavior.AllowGet);
            }
        }

        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult ChangePasswordEditor()
        {
            ChangePasswordEditorModel model = EchoparkProfileViewRepository.GetChangePasswordViewModel(base.Rendering, null);
            return View("~/Views/Echopark/Profile/ChangePasswordEditor.cshtml", model);
        }

        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult ProfileInformationEditor()
        {
            ProfileInformationModel model = EchoparkProfileViewRepository.GetProfileInformationViewModel(base.Rendering, null);
            return View("~/Views/Echopark/Profile/ProfileInformation.cshtml", model);
        }
        [HttpPost]
        [Authorize]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public ActionResult UpdateAlert(string key, string value)
        {
            BaseJsonResult baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
            ValidateModel(baseJsonResult);
            StringPropertyCollection propertyBag = new StringPropertyCollection
                    {
                        { key,value},
                    };

            baseJsonResult = ProfileEditorRepository.SaveProfile(EchoparkProfileViewRepository.GetProfile(VisitorContext.UserName), propertyBag);

            baseJsonResult.Data = EchoparkProfileViewRepository.GetUserProperties();

            return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        [Authorize]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public ActionResult UpdateAlertPreferences(AlertPreferenceInputModel model)
        {
            StringPropertyCollection propertyBag = new StringPropertyCollection();
            BaseJsonResult baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
            ValidateModel(baseJsonResult);

            var profile = EchoparkProfileViewRepository.GetProfile(VisitorContext.UserName);

            if (!string.IsNullOrEmpty(model.PhoneNumber))
            {
                propertyBag.Add(nameof(model.PhoneNumber), model.PhoneNumber);
                profile.PhoneNumber = model.PhoneNumber;
            }
            if (model.KeyValue != null && !string.IsNullOrEmpty(model.KeyValue.Key))
            {
                propertyBag.Add(model.KeyValue.Key, model.KeyValue.Value ?? "");
            }

            baseJsonResult = ProfileEditorRepository.SaveProfile(profile, propertyBag);

            baseJsonResult.Data = EchoparkProfileViewRepository.GetUserProperties();

            return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public ActionResult UpdateCarInformation(CarInformationModel model)
        {
            BaseJsonResult baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
            ValidateModel(baseJsonResult);
            StringPropertyCollection propertyBag = new StringPropertyCollection
                    {
                        { nameof(model.PreferredVehicleMake),model.PreferredVehicleMake},
                        { nameof(model.PreferredVehicleModel),model.PreferredVehicleModel},
                        { nameof(model.CurrentVehicleMake),model.CurrentVehicleMake},
                        { nameof(model.CurrentVehicleModel),model.CurrentVehicleModel},
                    };

            baseJsonResult = ProfileEditorRepository.SaveProfile(EchoparkProfileViewRepository.GetProfile(model.UserName), propertyBag);

            baseJsonResult.Data = EchoparkProfileViewRepository.GetUserProperties();

            return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Authorize]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public ActionResult UpdateProfileInformation(ProfileInformationModel model)
        {
            BaseJsonResult baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
            ValidateModel(baseJsonResult);

            if (!baseJsonResult.HasErrors)
            {
                StringPropertyCollection propertyBag = new StringPropertyCollection
                    {
                        { nameof(model.FirstName),model.FirstName ?? ""},
                        { nameof(model.LastName), model.LastName ?? ""},
                        { nameof(model.DOB),model.DOB?.ToString("yyyy-MM-dd") ?? ""}
                    };
                if (string.IsNullOrEmpty(model.PhoneNumber))
                {
                    var properties = EchoparkProfileViewRepository.GetUserProperties();
                    propertyBag.Add("GeneralSMSAlert", "false");
                    propertyBag.Add("PriceDropSMSAlert", "false");
                    propertyBag.Add("CarSoldSMSAlert", "false");
                    var phoneNumber = properties.GetPropertyOrDefault("DealerCommunicationAlert", "");

                    if (phoneNumber.Equals("Phone") || phoneNumber.Equals("SMS"))
                    {
                        propertyBag.Add("DealerCommunicationAlert", "");
                    }
                }
                if (!string.IsNullOrEmpty(model.UpdateAlertKey))
                {
                    propertyBag.Add(model.UpdateAlertKey, model.UpdateAlertValue);
                }

                baseJsonResult = ProfileEditorRepository.SaveProfile(new ProfileEditorInputModel()
                {
                    FirstName = model.FirstName ?? "",
                    LastName = model.LastName ?? "",
                    PhoneNumber = model.PhoneNumber ?? "",
                    EmailAddress = model.Email
                }, propertyBag);
            }
            baseJsonResult.Data = EchoparkProfileViewRepository.GetUserProperties();

            return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [AllowAnonymous]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult UpdateUser(UserOfferDetails inputModel)
        {           
            BaseJsonResult baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
            try
            {
               
                var profile = EchoparkProfileViewRepository.GetProfile(VisitorContext.UserName);               
                if (profile != null)
                {
                    StringPropertyCollection propertyBag = new StringPropertyCollection
                     {
                        { "VIN",inputModel.VIN },
                        { "Make",inputModel.Make },
                        { "Model",inputModel.Model  },
                        { "Year",inputModel.Year},
                        { "Trim",inputModel.Trim},
                        { "Mileage",inputModel.Mileage},
                        { "OfferValue",inputModel.OfferAmount},
                        { "OfferExpiration",inputModel.OfferValidation.ToString()}
                    };

                    baseJsonResult = ProfileEditorRepository.SaveProfile(profile, propertyBag);

                }
                return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
            }
            catch (Exception exception)
            {
                return Json(new BaseJsonResult("UpdateUser", exception, base.StorefrontContext, base.SitecoreContext), JsonRequestBehavior.AllowGet);
            }
        }
    }
}