﻿using Sitecore.Commerce.XA.Feature.Account.Models;
using Sitecore.Commerce.XA.Feature.Account.Models.InputModels;
using Sitecore.Commerce.XA.Foundation.Common.Context;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Echopark.Feature.Accounts.Models
{
    public class ChangePasswordModel : ChangePasswordInputModel
    {        
        /// <summary>
        /// Gets the _Password
        /// </summary>
        public static string _Password => "New password";
        public static string _ConfirmPassword => "Confirm new password";
        public static string PasswordRequiredMsg = "New password is required.";
        public static string ConfirmPasswordNotMatchMsg = "The new password and confirmation password do not match";
        public static string ConfirmPasswordRequiredMsg = "";


        [Required(ErrorMessage = nameof(PasswordRequiredMsg))]
        [DataType(DataType.Password)]
        [Display(Name = nameof(_Password))]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,}$", ErrorMessageResourceName = nameof(PasswordPatternErrorMessage), ErrorMessageResourceType = typeof(ChangePasswordModel))]        
        public string NewPassword { get; set; }

        [MaxLength(100)]
        [Display(Name = nameof(_ConfirmPassword))]
        [Required(ErrorMessageResourceName = nameof(ConfirmPasswordRequiredMsg), ErrorMessageResourceType = typeof(ChangePasswordModel))]
        [Compare("NewPassword", ErrorMessageResourceName = nameof(ConfirmPasswordNotMatchMsg), ErrorMessageResourceType = typeof(ChangePasswordModel))]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }

        
        public string OldPassword { get; set; }

        /// <summary>
        /// Gets the PasswordPatternErrorMessage
        /// Defines the PasswordPatternErrorMessage
        /// </summary>
        public static string PasswordPatternErrorMessage => "Invalid Password";
        [NotMapped]
        public string ErrorMessage { get; set; }
    }
}