﻿namespace Echopark.Feature.Accounts.Models
{
    public class EmailAPIConfig
    {
        public string EventCategory { get; set; }
        public string EventSource { get; set; }
        public string EventType { get; set; }
        public string EventId { get; set; }
        public string Url { get; set; }
        public string Authorization { get; set; }
    }
}