﻿using System;
using Echopark.Foundation.Common;
using Sitecore.Data;

namespace Echopark.Feature.Accounts
{
    /// <summary>
    /// Defines the login constants 
    /// </summary>
    public struct AccountConstants
    {
        /// <summary>
        /// Defines the viewpaths 
        /// </summary>
        public struct ViewPaths
        {
            /// <summary>
            /// Defines the folderpath 
            /// </summary>
            public static readonly string FolderPath = "~/Views/Echopark/Account/";
            public struct Login
            {
                public static readonly string LoginView = FolderPath + "Login.cshtml";
                public static readonly string ChangePassword = FolderPath + "Change Password.cshtml";
                public static readonly string ForgotPassword = FolderPath + "ForgotPassword.cshtml";
                public static readonly string ResetPassword = FolderPath + "ResetPassword.cshtml";
            }

            public struct Registration
            {
                public static readonly string AccountCreatedView = FolderPath + "AccountCreated.cshtml";
            }
        }
        /// <summary>
        /// Defines the error messages
        /// </summary>
        public struct ErrorMessages
        {
            /// <summary>
            /// Defines the error messages related to login
            /// </summary>
            public struct Login
            {
                public static readonly string InvalidLoginDetails = "Email ID or Password is incorrect";
                public static readonly string AccountLockedOut = "The account has been locked out";
            }
        }
        /// <summary>
        /// Defines the labels
        /// </summary>

        public struct Dictionary
        {
            public struct SingIn
            {
                public struct ValidationMessages
                {
                    public static string EmailRequired => "{1BE508C1-A590-4B58-9FDC-1695E72EFE62}";
                    public static string InvalidEmailAddress => "{2F965898-4631-482D-B25D-879F4CB68EF7}";
                    public static string MinimumPasswordLength => "{973F1358-6BF2-4BCB-A2D5-2C0CD8837909}";
                    public static string PasswordRequired => "{C37A4D55-464A-4DA3-9C42-CB7001B93FC6}";
                }
                public struct Labels
                {
                    public static string Email = "{10D32552-3D03-4A74-9B65-2D13B42B34D2}";
                    public static string Password = "{E5381E6E-826A-4B5A-A9B9-1EB1E07EA7F7}";
                }
                public struct ErrroMessages
                {
                    public static string LoginFailed = "{F80296FF-94DE-481A-9D9F-B07326E18063}";
                    public static string UserNotExist = "{9F05570E-8E4D-40A0-940C-EDB34BABB4D3}";
                    public static string InternalServerErrorMessage = "{04F713DE-D417-44FE-8702-BC95763AD8BB}";
                }
            }
            public struct Registration
            {
                public struct ErrorMessage
                {
                    public static string InvalidRegistrationRequest = "{11F5F536-83D1-4C70-83F5-5BA5528C7BFB}";
                    public static string InternalServerErrorMessage = "{02635A20-2A5F-4E70-B339-B5FC33099E09}";
                    public static string UserAlreadyExistErrorMessage = "{91A740AA-85C7-476C-936C-283AC378DC81}";
                    public static string InvalidFirstNameErrorMessage = "{35C822CC-F83A-4E31-BCAA-0610C6B28A9B}";
                    public static string InvalidLastNameErrorMessage = "{4C2CFDBD-1408-43FD-AD31-2F0943A998FD}";

                }
            }
        }

        public struct Template
        {
            public struct Registration
            {
                public static ID TemplateId = new ID("{B9B6D4F8-88E3-459A-85BA-FA277381CEE2}");
                public struct Fields
                {
                    public struct EmailAddress
                    {
                        public static ID EmailAddressLabel = new ID("{6C12C997-9F3D-4921-85CF-949F2F8F1EC4}");
                        public static ID EmailAddressHintText = new ID("{B3466EB2-9C5D-4C4D-A834-F63A949D17C7}");
                        public static ID EmailAddressMissingMessage = new ID("{F4A7E842-0BFE-49ED-82E2-8B7C6425972B}");
                        public static ID EmailAddressInvalidMessage = new ID("{487924D8-DBD5-4358-8D82-734B33B11486}");
                        public static ID EmailAddressMaxLengthMessage = new ID("{70A1C009-FCE3-4548-9CFE-57535BC055B0}");
                    }
                    public struct FirstName
                    {
                        public static ID FirstNameLabel = new ID("{AFA95949-AF20-4A9C-B590-8495BFE6A0A9}");
                        public static ID FirstNameHintText = new ID("{DAC49434-89A5-4333-B899-8A75D5FAA16E}");
                        public static ID FirstNameMissingMessage = new ID("{32B825D2-DAA7-442C-BE1B-A25BA6FA7DB7}");
                        public static ID FirstNameMaxLengthMessage = new ID("{D9548F02-150F-4912-9D96-0ADBCF1D92C5}");
                    }
                    public struct LastName
                    {
                        public static ID LastNameLabel = new ID("{B9A42133-BF35-4547-A650-C669A3F7092B}");
                        public static ID LastNameHintText = new ID("{039DF833-60A0-4C0C-B61D-B500516EF20C}");
                        public static ID LastNameMissingMessage = new ID("{67A532EF-A85E-4012-B4FC-1DC779309476}");
                        public static ID LastNameMaxLengthMessage = new ID("{8584B9BD-1D73-4459-B135-BC9D636C7C46}");

                    }
                    public struct Password
                    {
                        public static ID PasswordLabel = new ID("{4CED60CA-F09B-46F9-95F3-C957B6D55A93}");
                        public static ID PasswordMissingMessage = new ID("{2A870801-66B1-4025-895D-C25561DDA88C}");
                        public static ID PasswordHintText = new ID("{783B1DAE-98D2-4D12-A1D8-A972EA999D7E}");
                        public static ID PasswordLengthMessage = new ID("{95CFD479-C319-48F5-AF19-CCF2B5836668}");
                        public static ID PasswordConditions = new ID("{700ED223-57AE-4BFB-AB9E-99B7A7982F1D}");
                    }
                    public struct RepeatPassword
                    {
                        public static ID RepeatPasswordLabel = new ID("{9D57EA4D-F6D0-4544-843D-A24195DCF32D}");
                        public static ID RepeatPasswordMissingMessage = new ID("{AD25E7E6-CEE7-44FC-B218-E72E5225CCA4}");
                        public static ID PasswordsDoNotMatchMessage = new ID("{65A017FC-7205-4578-A550-870FC3044394}");
                    }

                    public struct CreateAccount
                    {
                        public static ID CreateAccountHeader = new ID("{4F9BE5B7-0C79-4976-8C23-C25939BF4BED}");
                        public static ID CreateAccountButtonLabel = new ID("{9541FE8A-E61A-451F-8C51-BF2343C8F41A}");
                        public static ID CreateAccountButtonInProgressLabel = new ID("{ADC45B44-4793-40B4-8883-3DC378F7514A}");
                    }
                    public struct Cancel
                    {
                        public static ID CreateAccountButtonLabel = new ID("{16C26302-8193-4678-8392-C7ADC0064984}");
                    }
                    public struct PhoneNumber
                    {
                        public static ID PhoneNumberLabel = new ID("{9DA93B1C-A4A1-4EF4-B267-1911B34F4E33}");
                        public static ID PhoneNumberHintText = new ID("{C96D6CD0-031E-4130-96B5-EF6D47520D38}");
                        public static ID PhoneNumberMaxLengthMessage = new ID("{0610D53C-A48F-477C-8AF8-22A152047F3A}");
                        public static ID PhoneNumberInvalidMessage = new ID("{79C5542B-E248-4EF5-A889-F52EC1E0DEC7}");
                        public static ID PhoneNumberRequiredMessage = new ID("{20FF7F87-F67C-439E-8D85-0E2B5F794A53}");

                    }

                    public struct Others
                    {
                        public static ID HaveAnAccount = new ID("{23F5E492-994F-432E-A1F7-9328F5EF9EA9}");
                        public static ID SignInLink = new ID("{C1F1E2DE-2BD7-4101-9355-231F4372BDE7}");
                        public static ID PrivacyPolicyandTerms = new ID("{07F874A0-AA2C-431B-AEA1-42EF6178579A}");
                        public static ID ReceiveEchoparkcommunicationsLabel = new ID("{E9106191-4FD5-4329-9D16-E82034733436}");
                        public static ID OptintoSMSfromEchoParkLabel = new ID("{F0AA4D4B-23EB-454D-A886-1E5A32112110}");
    
                    }
                }
            }
            public struct Login
            {
                public static ID TemplateId = new ID("{450E6CCD-3AF3-4E14-A946-B6BF8C37C12C}");
                public struct Fields
                {
                    public static ID DefaultPageAfterPage = new ID("{EDEA1B83-E65F-4236-9499-6CF3B80A366D}");
                }
            }
            public struct AccountConfirmation
            {
                public static ID TemplateId = new ID("{231A866E-A36E-41BE-A3AC-BF4556CBB7D0}");
                public struct Fields
                {
                    public static ID AccountSuccessImage = new ID("{EE89ABF5-4A7E-4A39-934F-A7481D6D1EFF}");
                    public static ID AccountCreatedHeaderText = new ID("{A8CADDEF-BAAC-4AA9-9DDC-AB32D1508F7B}");
                    public static ID AccountSuccessMessage = new ID("{D3B721E5-067C-4E6E-8A23-53F177DFAEDA}");
                    public static ID ShopAllCarsLink = new ID("{933753C6-5966-4824-BA20-5E9F5E7D9EB2}");
                    public static ID ViewMyAccount = new ID("{622D7E5D-0BF9-42EE-9438-DDCC68BE0514}");
                    public static ID CloseIcon = new ID("{BCAC8FA1-4F36-4D61-B95C-BC518AF56525}");
                }
            }
            public struct LoginPage
            {
                public static ID TemplateId = new ID("{450E6CCD-3AF3-4E14-A946-B6BF8C37C12C}");
                public struct Fields
                {
                    public static ID Header = new ID("{14345693-C572-443B-B6DC-F6B03C549F96}");
                    public static ID WelcomeMessageMain = new ID("{44B8853F-D791-4AF8-9109-4F155C6C6DCF}");
                    public static ID NewUser = new ID("{A645CED2-9064-43E2-9E04-CC96275E247D}");
                    public static ID CreateAccountText = new ID("{5FBB7757-872E-4C74-92DB-E312512048C5}");
                    public static ID EmailPlaceHolderText = new ID("{EC3C72F1-5B22-4F08-BB0C-D6B9EEB653B7}");
                    public static ID PasswordPlaceHolderText = new ID("{A0810973-0B07-4F84-95B3-E0B2D853A0C0}");
                    public static ID SignInCTAText=new ID("{D48DBC51-E81B-4076-BEE9-9E679D40E81E}");
                    public static ID ForgotPasswordText = new ID("{202794A4-E3DA-408C-AA70-A5AA535A1302}");
                    public static ID OrText= new ID("{12D5B821-DE09-482A-B531-F9DEA0CB8459}");
                    public static ID SignInWithGoogleCTAText= new ID("{FAAA7244-F9DA-4D59-89AA-AA8A3D5ED09E}");
                    public static ID SignInWithFacebookCTAText= new ID("{13B07B33-475B-49DB-9653-80255ED4E96A}");
                    public static ID SignInWithAppleCTAText= new ID("{20937042-43AE-493F-B2DD-4FAD80F937E5}");
                    public static ID CloseIcon= new ID("{046FFAF8-119C-491E-BE94-277AE18EBBC6}");
                    public static ID DefaultPageAfterPage= new ID("{EDEA1B83-E65F-4236-9499-6CF3B80A366D}");
                }
            }
        }

        public struct ProfileProperties
        {
            public static readonly string ForgotPasswordToken = "ForgotPasswordToken";
            public static readonly string ForgotPasswordTokenCreatedDate = "ForgotPasswordTokenCreatedDate";
            public static readonly string IsForgotPasswordTokenUsed = "IsForgotPasswordTokenUsed";
        }

        public struct Profile
        {
            public static string PhoneAlert = "Phone";
            public static string DealerComminicationAlertField = "DealerCommunicationAlert";
            public static string PhoneNumber = "PhoneNumber";
        }
    }
}