﻿using Echopark.Foundation.Common.Utilities;
using Echopark.Foundation.Common;
using Sitecore;
using Sitecore.Diagnostics;
using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;
using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using Sitecore.Data.Items;
using Echopark.Foundation.Common.Extensions;

namespace Echopark.Feature.Accounts.Models
{
    public class AlertPreferenceModel : Sitecore.Commerce.XA.Foundation.Common.Models.BaseCommerceRenderingModel
    {
        public static Item DataSource => SitecoreUtility.GetRenderingDatasourceItem() ?? SitecoreUtility.GetContextItem();

        [Required(ErrorMessageResourceName = nameof(PhoneNumberMissingMessage), ErrorMessageResourceType = typeof(AlertPreferenceModel))]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessageResourceName = nameof(PhoneNumberInvalidMessage), ErrorMessageResourceType = typeof(AlertPreferenceModel))]
        public string PhoneNumber { get; set; }

        public bool GeneralEmailAlert { get; set; }
        public bool GeneralSMSAlert { get; set; }
        public bool PriceDropEmailAlert { get; set; }
        public bool PriceDropSMSAlert { get; set; }
        public bool CarSoldEmailAlert { get; set; }
        public bool CarSoldSMSAlert { get; set; }
        public string DealerCommunicationAlert { get; set; }
        public string UserName { get; set; }

        public string AlertPreferenceHeader { get; set; }
        public string GeneralCommunicationTitle { get; set; }
        public string GeneralCommunicationDescription { get; set; }
        public string GeneralCommunicationEmailLabel { get; set; }
        public string GeneralCommunicationSMSLabel { get; set; }
        public string PriceDropAlertTitle { get; set; }
        public string PriceDropAlertDescription { get; set; }
        public string PriceDropAlertEmailLabel { get; set; }
        public string PriceDropAlertSMSLabel { get; set; }
        public string CarSoldAlertTitle { get; set; }
        public string CarSoldAlertDescription { get; set; }
        public string CarSoldAlertEmailLabel { get; set; }
        public string CarSoldAlertSMSLabel { get; set; }
        public string DealershipCommunicationAlertTitle { get; set; }
        public string DealershipCommunicationAlertDescription { get; set; }
        public string DealershipCommunicationAlertEmailLabel { get; set; }
        public string DealershipCommunicationAlertSMSLabel { get; set; }
        public string DealershipCommunicationAlertPhoneLabel { get; set; }

        public string PhoneNumberDialogMessage { get; set; }
        public string PhoneNumberLabel { get; set; }
        public static string PhoneNumberLengthMessage { get; set; } = DataSource.FieldValue(Templates.ProfileAlterPreferences.Fields.PhoneNumberLengthMessage);
        public static string PhoneNumberInvalidMessage { get; set; } = DataSource.FieldValue(Templates.ProfileAlterPreferences.Fields.PhoneNumberInvalidMessage);
        public static string PhoneNumberMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileAlterPreferences.Fields.PhoneNumberMissingMessage);
        public string SaveButtonLabel { get; set; }
        public string CancelButtonLabel { get; set; }



        public void Initialize(IRendering rendering, Sitecore.Commerce.Entities.Customers.CommerceUser user = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            if (user != null)
            {
                UserName = Context.User.LocalName;
                try
                {
                    PhoneNumber = user.GetPropertyValue("Phone") as string;
                    GeneralEmailAlert = System.Convert.ToBoolean(user.GetPropertyValue("GeneralEmailAlert"));
                    GeneralSMSAlert = System.Convert.ToBoolean(user.GetPropertyValue("GeneralSMSAlert"));
                    PriceDropEmailAlert = System.Convert.ToBoolean(user.GetPropertyValue("PriceDropEmailAlert"));
                    PriceDropSMSAlert = System.Convert.ToBoolean(user.GetPropertyValue("PriceDropSMSAlert"));
                    CarSoldEmailAlert = System.Convert.ToBoolean(user.GetPropertyValue("CarSoldEmailAlert"));
                    CarSoldSMSAlert = System.Convert.ToBoolean(user.GetPropertyValue("CarSoldSMSAlert"));
                    DealerCommunicationAlert = user.GetPropertyValue("DealerCommunicationAlert") as string;
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                }
            }
            if (rendering != null && rendering.Item != null)
            {
                Item item = rendering.Item;
                AlertPreferenceHeader = item.Fields[Templates.ProfileAlterPreferences.Fields.AlertPreferenceHeader]?.Value;
                GeneralCommunicationTitle = item.Fields[Templates.ProfileAlterPreferences.Fields.GeneralCommunicationTitle]?.Value;
                GeneralCommunicationDescription = item.Fields[Templates.ProfileAlterPreferences.Fields.GeneralCommunicationDescription]?.Value;
                GeneralCommunicationEmailLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.GeneralCommunicationEmailLabel]?.Value;
                GeneralCommunicationSMSLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.GeneralCommunicationSMSLabel]?.Value;
                PriceDropAlertTitle = item.Fields[Templates.ProfileAlterPreferences.Fields.PriceDropAlertTitle]?.Value;
                PriceDropAlertDescription = item.Fields[Templates.ProfileAlterPreferences.Fields.PriceDropAlertDescription]?.Value;
                PriceDropAlertEmailLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.PriceDropAlertEmailLabel]?.Value;
                PriceDropAlertSMSLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.PriceDropAlertSMSLabel]?.Value;
                CarSoldAlertTitle = item.Fields[Templates.ProfileAlterPreferences.Fields.CarSoldAlertTitle]?.Value;
                CarSoldAlertDescription = item.Fields[Templates.ProfileAlterPreferences.Fields.CarSoldAlertDescription]?.Value;
                CarSoldAlertEmailLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.CarSoldAlertEmailLabel]?.Value;
                CarSoldAlertSMSLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.CarSoldAlertSMSLabel]?.Value;
                DealershipCommunicationAlertTitle = item.Fields[Templates.ProfileAlterPreferences.Fields.DealershipCommunicationAlertTitle]?.Value;
                DealershipCommunicationAlertDescription = item.Fields[Templates.ProfileAlterPreferences.Fields.DealershipCommunicationAlertDescription]?.Value;
                DealershipCommunicationAlertEmailLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.DealershipCommunicationAlertEmailLabel]?.Value;
                DealershipCommunicationAlertSMSLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.DealershipCommunicationAlertSMSLabel]?.Value;
                DealershipCommunicationAlertPhoneLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.DealershipCommunicationAlertPhoneLabel]?.Value;
                PhoneNumberLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.PhoneNumberLabel]?.Value;
                PhoneNumberLengthMessage = item.Fields[Templates.ProfileAlterPreferences.Fields.PhoneNumberLengthMessage]?.Value;
                PhoneNumberInvalidMessage = item.Fields[Templates.ProfileAlterPreferences.Fields.PhoneNumberInvalidMessage]?.Value;
                PhoneNumberMissingMessage = item.Fields[Templates.ProfileAlterPreferences.Fields.PhoneNumberMissingMessage]?.Value;
                SaveButtonLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.SaveButtonLabel]?.Value;
                CancelButtonLabel = item.Fields[Templates.ProfileAlterPreferences.Fields.CancelButtonLabel]?.Value;
                PhoneNumberDialogMessage = item.Fields[Templates.ProfileAlterPreferences.Fields.PhoneNumberDialogMessage]?.Value;
            }
        }
    }
}