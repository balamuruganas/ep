﻿
namespace Echopark.Feature.Accounts.Services
{
    using Echopark.Feature.Accounts.Models;
    using Echopark.Foundation.Common;
    using Newtonsoft.Json;
    using System;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;

    public class MailServices
    {
        /// <summary>
        /// Sending the Mail Based on EventType Parameter i.e EventType="ForgotPassword", EventType="CreateAccount", 
        /// </summary>
        /// <param name="emailBody"></param>
        /// <returns></returns>
        public static bool EmailNotification(EmailNotifyArguments args)
        {
            bool flag = false;
            args.EventCategory = CustomSettings.Accounts.MailNotificationEventCategory;
            args.EventSource = CustomSettings.Accounts.MailNotificationEventSource;
            args.EventId = CustomSettings.Accounts.MailNotificationEventId;
            args.Time = DateTime.Now;

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var url = CustomSettings.Accounts.MailNotificationEmailURL;
                client.DefaultRequestHeaders.Add("Authorization", CustomSettings.Accounts.MailNotificationAuthorization);
                var json = JsonConvert.SerializeObject(args);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = client.PostAsync(url, data);

                HttpResponseMessage Res = response.Result;
                if (Res.IsSuccessStatusCode)
                {
                    flag = true;
                }
            }
            return flag;
        }
        public static bool NotifyUserOnCreateAccount(EmailNotifyArguments args)
        {
            bool flag = false;
            string config = CustomSettings.Accounts.CreateAccountEmailConfig;
            if (string.IsNullOrEmpty(config))
            {
                return flag;
            }
            EmailAPIConfig emailAPIConfig = JsonConvert.DeserializeObject<EmailAPIConfig>(config);
            args.EventCategory = emailAPIConfig.EventCategory;
            args.EventSource = emailAPIConfig.EventSource;
            args.EventId = emailAPIConfig.EventId;
            args.EventType = emailAPIConfig.EventType;
            args.Time = DateTime.Now;

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", emailAPIConfig.Authorization);
                var json = JsonConvert.SerializeObject(args);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = client.PostAsync(emailAPIConfig.Url, data);

                HttpResponseMessage Res = response.Result;
                if (Res.IsSuccessStatusCode)
                {
                    flag = true;
                }
            }
            return flag;
        }
    }
}