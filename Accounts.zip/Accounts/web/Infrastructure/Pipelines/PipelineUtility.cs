﻿using System;
using Sitecore.Commerce.Pipelines;
using Sitecore.Commerce.Services;
using Sitecore.Diagnostics;
using Sitecore.Pipelines;

namespace Echopark.Feature.Accounts.Infrastructure.Pipelines
{
    public static class PipelineUtility
    {
        public const string CartLineItemIdDelimiter = "|";

        public const string SellableItemIdIdDelimiter = ",";

        public const string SellableItemsIdIdDelimiter = "|";

        public const string CustomersPrefix = "Entity-Customer-";

        public const string SellableItemPrefix = "Entity-SellableItem-";

        public static TResult RunConnectPipeline<TRequest, TResult>(string pipelineName, TRequest request) where TRequest : ServiceProviderRequest where TResult : ServiceProviderResult, new()
        {
            ServicePipelineArgs servicePipelineArgs = new ServicePipelineArgs(request, new TResult());
            CorePipeline.Run(pipelineName, servicePipelineArgs);
            return servicePipelineArgs.Result as TResult;
        }

        internal static SystemMessage CreateSystemMessage(Exception ex)
        {
            return new SystemMessage
            {
                Message = ex.ToString()
            };
        }

        internal static SystemMessage CreateSystemMessage(string message)
        {
            return new SystemMessage
            {
                Message = message
            };
        }

        internal static void ValidateArguments<TRequest, TResult>(ServicePipelineArgs args, out TRequest request, out TResult result) where TRequest : ServiceProviderRequest where TResult : ServiceProviderResult
        {
            Assert.ArgumentNotNull(args, "args");
            Assert.ArgumentNotNull(args.Request, "args.Request");
            Assert.ArgumentNotNull(args.Request.RequestContext, "args.Request.RequestContext");
            Assert.ArgumentNotNull(args.Result, "args.Result");
            request = args.Request as TRequest;
            result = args.Result as TResult;
            Assert.IsNotNull(request, "The parameter args.Request was not of the expected type.  Expected {0}.  Actual {1}.", typeof(TRequest).Name, args.Request.GetType().Name);
            Assert.IsNotNull(result, "The parameter args.Result was not of the expected type.  Expected {0}.  Actual {1}.", typeof(TResult).Name, args.Result.GetType().Name);
        }
    }
}