﻿using Echopark.Foundation.Common.Utilities;
using Sitecore.Commerce.XA.Feature.Account.Models;
using Sitecore.Data.Items;
using System.ComponentModel.DataAnnotations;
using Echopark.Foundation.Common.Extensions;
using Echopark.Foundation.Common.CustomValidations;
using System.ComponentModel;

namespace Echopark.Feature.Accounts.Models
{
    public class RegistrationUserRenderingViewModel : RegistrationUserRenderingModel
    {
        #region FirstName
        public static string FirstNameRequiredMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.FirstName.FirstNameMissingMessage);
        public static string InvalidFirstNameErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.Registration.ErrorMessage.InvalidFirstNameErrorMessage);
        public static string FirstNameMaxLengthMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.FirstName.FirstNameMaxLengthMessage);
        [Required(ErrorMessageResourceName = nameof(FirstNameRequiredMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [StringLength(maximumLength: 30, ErrorMessageResourceName = nameof(FirstNameMaxLengthMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [RegularExpression(@"^[a-zA-Z ]*$", ErrorMessageResourceName = nameof(InvalidFirstNameErrorMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        public new string FirstName { get; set; }
        #endregion FirstNameEnd
        #region LastName
        public static string LastNameLabel => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.LastName.LastNameLabel);
        public static string LastNameRequiredMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.LastName.LastNameMissingMessage);
        public static string InvalidLastNameErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.Registration.ErrorMessage.InvalidLastNameErrorMessage);
        public static string LastNameMaxLengthMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.LastName.LastNameMaxLengthMessage);
        [Required(ErrorMessageResourceName = nameof(LastNameRequiredMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [StringLength(maximumLength: 30, ErrorMessageResourceName = nameof(LastNameMaxLengthMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [RegularExpression(@"^[a-zA-Z ]*$", ErrorMessageResourceName = nameof(InvalidLastNameErrorMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        public new string LastName { get; set; }
        #endregion LastName
        #region Password
        public static string PasswordLabel => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.Password.PasswordLabel);
        public static string PasswordRequiredMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.Password.PasswordMissingMessage);
        public static string PasswordMinLengthMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.Password.PasswordLengthMessage);
        [Required(ErrorMessageResourceName = nameof(PasswordRequiredMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [DataType(DataType.Password)]
        [StringLength(maximumLength:16,MinimumLength = 6, ErrorMessageResourceName = nameof(PasswordMinLengthMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [RegularExpression(@"^((?!.*[\s])(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,})", ErrorMessageResourceName = nameof(PasswordMinLengthMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        public new string Password { get; set; }
        #endregion Password

        #region ConfirmPassword
        public static string ConfirmPasswordRequiredMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.RepeatPassword.RepeatPasswordMissingMessage);
        public static string ConfirmPasswordsDoNotMatch => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.RepeatPassword.PasswordsDoNotMatchMessage);
        [Required(ErrorMessageResourceName = nameof(ConfirmPasswordRequiredMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessageResourceName = nameof(ConfirmPasswordsDoNotMatch), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [DataType(DataType.Password)]
        [StringLength(maximumLength: 16, MinimumLength = 6, ErrorMessageResourceName = nameof(ConfirmPasswordsDoNotMatch), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        public new string ConfirmPassword { get; set; }
        #endregion ConfirmPassword

        #region PhoneNumber
        public static string PhoneNumberLabel => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.PhoneNumber.PhoneNumberLabel);
        public static string PhoneNumberInvalidMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.PhoneNumber.PhoneNumberInvalidMessage);
        public static string PhoneNumberRequiredMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.PhoneNumber.PhoneNumberRequiredMessage);

        public static string PhoneNumberMaxLengthMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.PhoneNumber.PhoneNumberMaxLengthMessage);
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessageResourceName = nameof(PhoneNumberInvalidMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [RequiredWhen("OptintoSMSfromEchoPark", true, AllowEmptyStrings = false, ErrorMessageResourceName = nameof(PhoneNumberRequiredMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        public string PhoneNumber { get; set; }
        public bool OptintoSMSfromEchoPark { get; set; }

        #endregion PhoneNumber
        #region EmailORUsername
        public static string EmailAddressMissingMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.EmailAddress.EmailAddressMissingMessage);
        public static string EmailAddressInvalidMessage => DataSource.FieldValue(AccountConstants.Template.Registration.Fields.EmailAddress.EmailAddressInvalidMessage);
        [Required(ErrorMessageResourceName = nameof(EmailAddressMissingMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessageResourceName = nameof(EmailAddressInvalidMessage), ErrorMessageResourceType = typeof(RegistrationUserRenderingViewModel))]
        public new string UserName { get; set; }
        #endregion EmailORUsername
        /// <summary>
        /// Gets or sets the receive echopark communications
        /// </summary>
        public bool ReceiveEchoparkCommunications { get; set; }
        /// <summary>
        /// Gets the DataSource
        /// </summary>
        public static Item DataSource => SitecoreUtility.GetRenderingDatasourceItem() ?? SitecoreUtility.GetContextItem();
        /// <summary>
        /// Gets or sets the returnurl
        /// </summary>
        public string ReturnUrl { get; set; }
        /// <summary>
        /// Define the invalid login error message
        /// </summary>
        public static string InvalidRegistrationRequest => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.Registration.ErrorMessage.InvalidRegistrationRequest);
        /// <summary>
        /// Define the internal server errormessage
        /// </summary>
        public static string InternalServerErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.Registration.ErrorMessage.InternalServerErrorMessage);

        /// <summary>
        /// Define the internal server errormessage
        /// </summary>
        public static string UserAlreadyExistErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.Registration.ErrorMessage.UserAlreadyExistErrorMessage);

    }
}