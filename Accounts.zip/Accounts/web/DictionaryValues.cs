﻿
namespace Echopark.Feature.Accounts
{
    using Echopark.Foundation.Common.Utilities;
    using Sitecore;

    public class DictionaryValues
    {
        public struct Settings
        {
                        
        }

    }
}
    