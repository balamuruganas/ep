﻿using Echopark.Foundation.Common.Extensions;
using Echopark.Foundation.Common.Utilities;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;
using System.ComponentModel.DataAnnotations;


namespace Echopark.Feature.Accounts.Models
{
    public class ChangePasswordEditorModel : Sitecore.Commerce.XA.Foundation.Common.Models.BaseCommerceRenderingModel
    {
        public static Item DataSource => SitecoreUtility.GetRenderingDatasourceItem() ?? SitecoreUtility.GetContextItem();

        [Required(ErrorMessageResourceName = nameof(CurrentPasswordMissingMessage), ErrorMessageResourceType = typeof(ChangePasswordEditorModel))]
        [MinLength(6, ErrorMessageResourceName = nameof(CurrentPasswordLengthMessge), ErrorMessageResourceType = typeof(ChangePasswordEditorModel))]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        public string CurrentPassword { get; set; }

        [Required(ErrorMessageResourceName = nameof(NewPasswordMissingMesage), ErrorMessageResourceType = typeof(ChangePasswordEditorModel))]
        [DataType(DataType.Password)]
        [MinLength(6, ErrorMessageResourceName = nameof(NewPasswordLengthMessage), ErrorMessageResourceType = typeof(ChangePasswordEditorModel))]
        [RegularExpression(@"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,}", ErrorMessageResourceName = nameof(NewPasswordRegexValidationMessage), ErrorMessageResourceType = typeof(ChangePasswordEditorModel))]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        public string NewPassword { get; set; }

        public string SecurityLabel { get; set; }
        public string PasswordLabel { get; set; }
        public string PasswordMask { get; set; }
        public string CurrentPasswordLabel { get; set; }
        public static string CurrentPasswordMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.CurrentPasswordMissingMessage);
        public static string CurrentPasswordLengthMessge { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.CurrentPasswordLengthMessge);
        public static string CurrentPasswordInvalidMessge { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.CurrentPasswordInvalidMessage);
        public static string SamePasswordErrorMessage { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.SamePasswordErrorMessage);
        public string CurrentPasswordHintText { get; set; }
        public string NewPasswordLabel { get; set; }
        public static string NewPasswordMissingMesage { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.NewPasswordMissingMesage);
        public static string NewPasswordLengthMessage { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.NewPasswordLengthMessage);
        public static string NewPasswordRegexValidationMessage { get; set; } = DataSource.FieldValue(Templates.ProfileChangePassword.Fields.NewPasswordRegexValidationMessage);
        public string NewPasswordHintText { get; set; }
        public string PasswordInfo { get; set; }
        public string ChangeButtonLabel { get; set; }
        public string SaveButtonLabel { get; set; }
        public string CancelButtonLabel { get; set; }

        public string UserName { get; set; }

        public void Initialize(IRendering rendering, Sitecore.Commerce.Entities.Customers.CommerceUser user = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            if (user != null)
            {
                UserName = Context.User.LocalName;
            }
            if (rendering != null && rendering.Item != null)
            {
                Item item = rendering.Item;

                SecurityLabel = item.Fields[Templates.ProfileChangePassword.Fields.SecurityLabel]?.Value;
                PasswordLabel = item.Fields[Templates.ProfileChangePassword.Fields.PasswordLabel]?.Value;
                PasswordMask = item.Fields[Templates.ProfileChangePassword.Fields.PasswordMask]?.Value;
                CurrentPasswordLabel = item.Fields[Templates.ProfileChangePassword.Fields.CurrentPasswordLabel]?.Value;
                CurrentPasswordMissingMessage = item.Fields[Templates.ProfileChangePassword.Fields.CurrentPasswordMissingMessage]?.Value;
                CurrentPasswordLengthMessge = item.Fields[Templates.ProfileChangePassword.Fields.CurrentPasswordLengthMessge]?.Value;
                CurrentPasswordInvalidMessge = item.Fields[Templates.ProfileChangePassword.Fields.CurrentPasswordInvalidMessage]?.Value;
                NewPasswordLabel = item.Fields[Templates.ProfileChangePassword.Fields.NewPasswordLabel]?.Value;
                NewPasswordMissingMesage = item.Fields[Templates.ProfileChangePassword.Fields.NewPasswordMissingMesage]?.Value;
                NewPasswordLengthMessage = item.Fields[Templates.ProfileChangePassword.Fields.NewPasswordLengthMessage]?.Value;
                NewPasswordHintText = item.Fields[Templates.ProfileChangePassword.Fields.NewPasswordHintText]?.Value;
                SaveButtonLabel = item.Fields[Templates.ProfileChangePassword.Fields.SaveButtonLabel]?.Value;
                ChangeButtonLabel = item.Fields[Templates.ProfileChangePassword.Fields.ChangeButtonLabel]?.Value;
                CancelButtonLabel = item.Fields[Templates.ProfileChangePassword.Fields.CancelButtonLabel]?.Value;
                PasswordInfo = item.Fields[Templates.ProfileChangePassword.Fields.PasswordInfo]?.Value;
                NewPasswordRegexValidationMessage = item.Fields[Templates.ProfileChangePassword.Fields.NewPasswordRegexValidationMessage]?.Value;
            }
        }
    }
}