﻿using Echopark.Feature.Accounts.Models;
using Sitecore.Commerce.XA.Feature.Account.Models.InputModels;
using Sitecore.Commerce.XA.Foundation.Common;
using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;

namespace Echopark.Feature.Accounts.Repositories
{
    public interface IProfileViewRepository
    {
        AlertPreferenceModel GetAlertPreferencesViewModel(IRendering rendering, StringPropertyCollection propertyBag = null);

        CarInformationModel GetCarInformationViewModel(IRendering rendering, StringPropertyCollection propertyBag = null);

        ChangePasswordEditorModel GetChangePasswordViewModel(IRendering rendering, StringPropertyCollection propertyBag = null);
        ProfileInformationModel GetProfileInformationViewModel(IRendering rendering, StringPropertyCollection propertyBag = null);
        ProfileViewRenderingViewModel GetProfileViewModel(IRendering rendering, StringPropertyCollection propertyBag = null);

        ProfileEditorInputModel GetProfile(string userName, StringPropertyCollection propertyBag = null);
        StringPropertyCollection GetUserProperties();
    }
}