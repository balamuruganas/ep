﻿using Echopark.Feature.Accounts.Models;
using Echopark.Feature.Accounts.Services;
using Echopark.Foundation.Accounts.Services;
using Echopark.Foundation.Common;
using Echopark.Foundation.Common.Utilities;
using Sitecore.Commerce.XA.Feature.Account.Repositories;
using Sitecore.Commerce.XA.Foundation.Common.Context;
using Sitecore.Commerce.XA.Foundation.Common.Models;
using Sitecore.Commerce.XA.Foundation.Connect.Managers;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.Mvc;
using static Echopark.Feature.Accounts.AccountConstants;

namespace Echopark.Feature.Accounts.Controllers
{
    public class ForgotPasswordController : Sitecore.Commerce.XA.Feature.Account.Controllers.AccountController
    {
        private AccountsService accountsService = new AccountsService();
        public ForgotPasswordController(ILoginRepository loginRepository, IRegistrationRepository registrationRepository, IForgotPasswordRepository forgotPasswordRepository, IChangePasswordRepository changePasswordRepository, IAccountManager accountManager, IStorefrontContext storefrontContext, IModelProvider modelProvider, IContext sitecoreContext, IRegisterUserRepository registerUserRepository, ILoginUserRepository loginUserRepository) : base(loginRepository, registrationRepository, forgotPasswordRepository, changePasswordRepository, accountManager, storefrontContext, modelProvider, sitecoreContext, registerUserRepository, loginUserRepository)
        {

        }

        /// <summary>
        /// Rendering the forgot password section
        /// </summary>
        /// <returns></returns>
        public ActionResult RenderForgotPasswordAndEmailSentSection()
        {

            ForgotPasswordViewModel forgotPasswordViewModel = new ForgotPasswordViewModel();
            try
            {
                Item datasourceItem = SitecoreUtility.GetRenderingDatasourceItem();
                if (datasourceItem != null && datasourceItem.TemplateID == Templates.ForgotPasswordAndEmailSent.ID)
                {
                    forgotPasswordViewModel.forgotPasswordAndEmailSent = new ForgotPasswordAndEmailSent(datasourceItem);

                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }

            return View(AccountConstants.ViewPaths.FolderPath + "ForgotPassword.cshtml", forgotPasswordViewModel);
        }
        /// <summary>
        /// Email Sending functionality-Sendening the reset email to user account 
        /// </summary>
        /// <returns></returns>
        public ActionResult SendResetPasswordLink(string emailAddress)
        {

            int statusCode = 0;
            string message = string.Empty;
            if (!string.IsNullOrWhiteSpace(emailAddress))
            {
                try
                {
                    //check email is available in database or not
                    var user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + emailAddress).Result;

                    if (user == null)
                    {
                        return Json(new { Status = 2, Message = ForgotPasswordViewModel.EmailNotFound }, JsonRequestBehavior.AllowGet);
                    }
                    string forgotPassToken = System.Guid.NewGuid().ToString();
                    string queryParams = SitecoreUtility.GetContextDomain() + "\\" + user.Email + CommonConstants.Characters.Pipe + forgotPassToken;
                    string encryptedQueryParams = StringCipher.Encrypt(queryParams).Replace(CommonConstants.Characters.Space, CommonConstants.Characters.Plus);
                    var resetLink = CustomSettings.Common.EchoParkWebBaseURL + CommonConstants.Characters.ForwardSlash + "change-password?t=" + encryptedQueryParams;

                    List<KeyValuePair<string, string>> list = new List<KeyValuePair<string, string>>() {
                                new KeyValuePair<string, string>(ProfileProperties.ForgotPasswordToken, forgotPassToken),
                                new KeyValuePair<string, string>(ProfileProperties.ForgotPasswordTokenCreatedDate,DateTime.Now.ToString()),
                                new KeyValuePair<string, string>(ProfileProperties.IsForgotPasswordTokenUsed, "0")

                            };

                    accountsService.SetCustomProfilePropertyValues(SitecoreUtility.GetContextDomain() + "\\" + emailAddress, list);
                    var args = new EmailNotifyArguments()
                    {
                        Event = new Event()
                        {
                            Email = emailAddress,
                            Link= resetLink
                        },
                       
                        EventType = Enum.GetName(typeof(EventType), EventType.ForgotPassword)
                    };
                    bool flag = MailServices.EmailNotification(args);
                    if (flag)
                    {
                        statusCode = 1;
                        
                    }

                }
                catch (Exception ex)
                {
                    message = ex.Message;
                    Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                }

            }
           
            return Json(new { Status = statusCode, Message = message }, JsonRequestBehavior.AllowGet);
        }
    }
}