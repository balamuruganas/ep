﻿$(function () {
    $('#phonenumber').keyup(function () {
        $('.profile-phone-error').addClass('hide');
        $('.btn-profile-info-editor').removeAttr('disabled');
    });
    $('.btn-profile-info-cancel').click(function () {
        var dsc_email_attr = $('#dsc_email').attr('checked');
        if (typeof dsc_email_attr !== 'undefined' && dsc_email_attr !== false) {
            $('#dsc_email').prop('checked', true);
        }
        var dsc_sms_attr = $('#dsc_sms').attr('checked');
        if (typeof dsc_sms_attr !== 'undefined' && dsc_sms_attr !== false) {
            $('#dsc_sms').prop('checked', true);
        }
        var dsc_email_attr = $('#dsc_phone').attr('checked');
        if (typeof dsc_phone_attr !== 'undefined' && dsc_phone_attr !== false) {
            $('#dsc_phone').prop('checked', true);
        }
        $('#alert_key').val('')
        $('#alert_value').val('')
        $('.profile-phone-error').addClass('hide');
        var profiledobVal = $(".profile-dob").text();
        var profilephonenumber = $(".profile-phonenumber").text();
        var profilefirstname = $(".profile-firstname").text();
        var profilelastname = $(".profile-lastname").text();
        if (profilephonenumber == "Not Provided") {
            $("#phonenumber").prop("value", "");
        } else {
            $("#phonenumber").prop("value", profilephonenumber);
        }
        if (profilefirstname == "Not Provided") {
            $("#firstname").prop("value", "");
        } else {
            $("#firstname").prop("value", profilefirstname);
        }
        if (profilelastname == "Not Provided") {
            $("#lastname").prop("value", "");
        } else {
            $("#lastname").prop("value", profilelastname);
        }
        if (profiledobVal == "Not Provided") {
            $("#profileDOB").prop("value", "");
        } else {
            SetDateOfBirth($("#profileDOBHidden").val(), true);
        }
    });
    function clearPasswordFields() {
        $("#currentpassword,#newpassword").val("");
        var validateChangePasswordEditorForm = $("#ChangePasswordEditor").validate();
        validateChangePasswordEditorForm.resetForm();

        //reset unobtrusive field level, if it exists
        $("#ChangePasswordEditor").find("[data-valmsg-replace]")
            .removeClass("field-validation-error")
            .addClass("field-validation-valid")
            .empty();
    }

    $("#spanChangePassword,#btnCancelChangePassword").click(function () {
        if (this.id == "spanChangePassword") {
            GaTrack_AccountProfileCTA('', '', window.location.href);
        } else {
            GaTrack_AccountProfileCTA('Security', 'Cancel', '');
        }
        clearPasswordFields();
    });

    $("#btnCancelCarInfo").click(function () {
        GaTrack_AccountProfileCTA('Car information', 'Cancel', '');
    });


    $('.dsc_phone_popup_trigger,.trigger-check').click(function () {
        var validateAlertForm = $("#AlertPreferenceForm ").validate();
        validateAlertForm.resetForm();
        //reset unobtrusive field level, if it exists
        $("#ChangePasswordEditor").find("[data-valmsg-replace]")
            .removeClass("field-validation-error")
            .addClass("field-validation-valid")
            .empty();
    });
    var phoneNumberUpdateElement = null;
    //event for saving the phone number
    $(".dsc_popup_buttons .btn-save").click(function () {
        var apiUrl = "/api/cxa/Profile/UpdateAlertPreferences";
        var phoneNumber = $(this).closest(".dsc_phone_popup").find(".PhoneNumberFormat").eq(0).val();
        phoneNumberUpdateElement = $(this).closest(".dsc_phone_popup").find(".phoneNumberUpdateMessage");
        var PopupElement = $(this).closest(".form-togglebtn");
        if (IsValidPhoneNumber(phoneNumber)) {
            $.ajax({
                url: apiUrl,
                type: 'POST',
                data: {
                    "PhoneNumber": phoneNumber,
                    "KeyValue": {
                        "Key": $("#alert_key").val(),
                        "Value": $("#alert_value").val()
                    }
                },
                success: function (results) {
                    if (results.HasErrors) {
                        phoneNumberUpdateElement.removeClass("text-info").addClass("text-danger").text(results.Errors[0]);
                    }
                    else if (results.HasInfo) {
                        phoneNumberUpdateElement.removeClass("text-danger");
                        var phoneNumber = GetValue(results.Data, "Phone");
                        $(this).closest(".form-togglebtn").find(".trigger-check").prop("checked", true)
                        $('.profile-phonenumber,.PhoneNumberFormat').text(phoneNumber);
                        $("#phonenumber").prop("value", phoneNumber);
                        $("#phonenumber").parent().addClass('focused Active');
                        PopupElement.removeClass("show_dsc_phone");
                    }
                },
                error: function (error) {
                    console.log(error);
                }
            });
        }
    });
    $("#profileDOB").change(function () {
        $("#profileDOB").prop("value", $(this).val());
    });
    /* dsc_phone_popup */
    $('.dsc_phone_popup_trigger').click(function () {
        var viewPhonenumber = $(".profile-phonenumber").text() || "";
        var editPhonenumber = $("#phonenumber").val() || "";
        if ((viewPhonenumber === "" || !IsValidPhoneNumber(viewPhonenumber)) && editPhonenumber === "") {
            $('.dsc_phone_popup_trigger').removeClass('show_dsc_phone');
            $(this).addClass('show_dsc_phone');
            $('.form-togglebtn').removeClass('show_dsc_phone');
        }
    });
    $(document).on('change', '.trigger-check', function () {
        var viewPhonenumber = $(".profile-phonenumber").text() || "";
        var editPhonenumber = $("#phonenumber").val() || "";
        if ($(this).is(':checked') && (viewPhonenumber === "" || !IsValidPhoneNumber(viewPhonenumber)) && editPhonenumber === "") {
            $('.form-togglebtn').removeClass('show_dsc_phone');
            $(this).closest('.form-togglebtn').addClass('show_dsc_phone');
            $('.dsc_phone_popup_trigger').removeClass('show_dsc_phone');
        }
        else {
            $(this).closest('.form-togglebtn').removeClass('show_dsc_phone');

        }
    });
    if (!IsValidPhoneNumber($(".profile-phonenumber").text() || "")) {
        $("#dsc_email").prop('checked', true);
    }
});
function GaTrack_AccountProfileCTA(sectionElement, linkTitle, link) {
    dataLayer.push({
        'sectionElement': sectionElement,
        'linkTitle': linkTitle,
        'link': link
    });
    return true;
}
function IsValidPhoneNumber(phoneNumber) {
    if (phoneNumber == "Not Provided" || phoneNumber == "" || phoneNumber == undefined) {
        return false;
    }
    else {
        return phoneNumber.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/);
    }

}
function GetValue(data, key) {
    var item = data.filter(function (x) { if (x.Key == key) return x.Value });
    if (item.length > 0) {
        return item[0].Value;
    }
    return "";
}

function GaTrack_AlertPreferences(event) {
    if (event.type == "radio") {
        var linkTitle = "";
        if (event.id == "dsc_email") {
            linkTitle = "Email";
        }
        else if (event.id == "dsc_sms") {
            linkTitle = "SMS";
        }
        else if (event.id == "dsc_phone") {
            linkTitle = "Phone";
        }

        dataLayer.push({
            'elementTitle': 'Dealership communication',
            'linkTitle': linkTitle
        });
        return true;
    }
    else {

        if (event.name.indexOf("General") > -1) {
            var elementTitle = "General communication";
            var toggleState = $(event).is(':checked') ? 1 : 0;
            var toggleTitle = "";
            if (event.id == "gcemail") {
                toggleTitle = "Email";
            }
            else {
                toggleTitle = "SMS"
            }
        }
        else if (event.name.indexOf("PriceDrop") > -1) {
            var elementTitle = "Price drop alerts";
            var toggleState = $(event).is(':checked') ? 1 : 0;
            var toggleTitle = "";
            if (event.id == "paemail") {
                toggleTitle = "Email";
            }
            else {
                toggleTitle = "SMS"
            }
        }
        else if (event.name.indexOf("CarSold") > -1) {
            var elementTitle = "Car sold alerts";
            var toggleState = $(event).is(':checked') ? 1 : 0;
            var toggleTitle = "";
            if (event.id == "csemail") {
                toggleTitle = "Email";
            }
            else {
                toggleTitle = "SMS"
            }
        }

        dataLayer.push({
            'elementTitle': elementTitle,
            'toggleTitle': toggleTitle,
            'toggleState': toggleState
        });
        return true;

    }

}


//Altert
function UpdateAltert(e) {
    GaTrack_AlertPreferences(e);

    var phoneNumber = $(".profile-phonenumber").text() || "";
    $(e).closest(".dsc_phone_popup").find(".PhoneNumberFormat").focus();
    var attrName = $(e).attr('name') || "";
    $('#alert_key').val(attrName);
    ToggleRadioBtnBasedOnPhoneNumber(phoneNumber, e);
    var allowToUpdate = true;
    if (e.type == "radio") {
        var radioValue = $(e).val();
        $('#alert_value').val(radioValue);
        if (radioValue !== "Email" && !IsValidPhoneNumber(phoneNumber))
            allowToUpdate = false;
    }
    else {
        var isChecked = $(e).is(':checked');
        $('#alert_value').val(isChecked);
        if (attrName.toLowerCase().indexOf("emailalert") > 0) { //on email checked no need to check phone number validaion
            allowToUpdate = true;
        }
        else if (!IsValidPhoneNumber(phoneNumber) && isChecked)//attrName.toLowerCase().indexOf("phone") > 0 &&
        {
            allowToUpdate = false;
        }

    }

    if (e.id == "dsc_email" || allowToUpdate) {
        var apiUrl = "/api/cxa/Profile/UpdateAlertPreferences";
        $.ajax({
            url: apiUrl,
            type: 'POST',
            data: {
                "key": attrName,
                "KeyValue": {
                    "Key": $("#alert_key").val(),
                    "Value": $("#alert_value").val()
                }
            },
            success: function (results) {
                if (results.HasErrors) {
                    $('.profile-alert_update_error').text(results.Errors[0]);
                }
                else if (results.HasInfo) {
                    var phoneNumber = GetValue(results.Data, "Phone");
                    $('.profile-phonenumber,.PhoneNumberFormat').text(phoneNumber);
                    $("#phonenumber").prop("value", phoneNumber);
                    $("#phonenumber").parent().addClass('focused Active');
                }
            },
            error: function (error) {
                console.log(error);
            }
        });
    }
}
//On Cancel button click we are cheking the phone number is available or not based on that we are enaling the Email radio button
$('.btn-dsc-cancel').click(function () {
    var phoneNumber = $(".profile-phonenumber").text() || "";
    if (!IsValidPhoneNumber(phoneNumber)) {
        $('#dsc_email').prop('checked', true);
    }

});
$(".alert-cancel-btn").click(function () {
    $('.PhoneNumberFormat.Alert').val('');
    $(".phoneNumberUpdateMessage").html('');
    $('.error_msg').hide();
    $(this).closest(".form-togglebtn").removeClass("show_dsc_phone");
    var phoneNumber = $(".profile-phonenumber").text() || "";
    if (!IsValidPhoneNumber(phoneNumber)) {
        $(this).closest(".form-togglebtn").find(".trigger-check").prop("checked", false)
    }})


$("#general_dsc_phonenumberSaveBtn,#price_dsc_phonenumberSaveBtn,#car_dsc_phonenumberSaveBtn,#dealer_dsc_phonenumberSaveBtn,#dsc_phonenumberSaveBtn").click(function (e) {
    var popupId = $(e.currentTarget).attr('data-popupid');
    var id = "#" + popupId;
    var invalid = $(id).attr("aria-invalid");
    if (invalid == undefined && $(id).val() == "") {
        $(id + 'error_msg').html('Please provide a phone number');
        $(".error_msg").show();
    } else if (invalid || $(id).val() == "") {
        $(".error_msg").show();
    }
    
});
$('#general_dsc_phonenumber,#price_dsc_phonenumber,#car_dsc_phonenumber').keyup(function (e) {
    $('.error_msg').hide();
    var popupId = $(e.currentTarget).attr('id');
    var id = "#" + popupId + "updatemsg";
    $(id).text("");
});
function ToggleRadioBtnBasedOnPhoneNumber(phoneNumber, event) {
    if (!IsValidPhoneNumber(phoneNumber)) {
        if (event.id == "gcsms") {
            $("#pasms,#cssms,#dsc_sms,#dsc_phone").prop('checked', false);
            $("#dsc_email").prop('checked', true);

        }
        else if (event.id == "pasms") {
            $("#gcsms,#cssms,#dsc_sms,#dsc_phone").prop('checked', false);
            $("#dsc_email").prop('checked', true);
        }
        else if (event.id == "cssms") {
            $("#gcsms,#pasms,#dsc_sms,#dsc_phone").prop('checked', false);
            $("#dsc_email").prop('checked', true);
        }
        else if (event.id == "dsc_sms") {
            $("#gcsms,#pasms,#cssms,#dsc_phone").prop('checked', false);
        }
        else if (event.id == "dsc_phone") {
            $("#gcsms,#pasms,#cssms,#dsc_sms").prop('checked', false);
        }
    }
}


function AlertPreferenceForm_OnComplete(results) {
}

function AlertPreferenceForm_OnSuccess(results) {
    if (results.HasErrors) {

        $('.profile-alert_update_error').text(results.Errors[0]);
    }
    else {
        var phoneNumber = GetValue(results.Data, "Phone");
        if (phoneNumber == "") {
            $('.profile-alert_dsc_phone_error').text($('#phonenumber').attr('data-val-required'));
        }
        else {
            $('.profile-phonenumber,.PhoneNumberFormat').text(phoneNumber);
            $("#phonenumber").prop("value", phoneNumber);
            $("#phonenumber").parent().addClass('focused Active');
        }
        $('.dsc_phone_popup_trigger').removeClass('show_dsc_phone');
    }

    $('#dsc_email').removeAttr('checked');
    $('#dsc_sms').removeAttr('checked');
}

//Car Information
function CarInformationForm_OnSuccess(results) {
    if (results.HasErrors) {
        $('.profile-carinfo_update_error').text(results.Errors[0])
    }
    else {
        var data = results.Data;
        $('.preferredcar_make').text(GetValue(data, "PreferredVehicleMake"));
        $('.preferredcar_model').text(GetValue(data, "PreferredVehicleModel"));
        $('.currentcar_make').text(GetValue(data, "CurrentVehicleMake"));
        $('.currentcar_model').text(GetValue(data, "CurrentVehicleModel"));
        $('.account_profile_panel').removeClass('editable');
    }
}

function CarInformationForm_OnBegin() {

    if ($("#preferredcar_make :selected").val() != "Make" || $("#preferredcar_model :selected").val() != "Model") {
        GaTrack_CarInformation("Preferred car type", $("#preferredcar_make :selected").val(), $("#preferredcar_model :selected").val());
    }
    if ($("#currentcar_make :selected").val() != "Make" || $("#currentcar_model :selected").val() != "Model") {
        GaTrack_CarInformation("Current car", $("#currentcar_make :selected").val(), $("#currentcar_model :selected").val());
    }
    GaTrack_AccountProfileCTA('Car information', 'Save', '');
}

function GaTrack_CarInformation(elementName, make, model) {
    dataLayer.push({
        'elementTitle': elementName,
        'make': make,
        'model': model
    });
    return true;

}

function CarInformationForm_OnComplete(results) {
    if (results.responseJSON != undefined && !results.responseJSON.HasErrors) {
        $('.account_profile_panel').removeClass('editable');
    }
}
//Change Password
function ChangePassword_OnSuccess(results) {
    if (results.HasErrors) {
        $('.current_password_error').html('<span id="currentpassword-error" class="">' + results.Errors[0] + '</span>')
        $('.current_password_error').show();
    }
    else {
        $('.account_profile_panel').removeClass('editable');
    }
}
function ChangePassword_OnComplete(results) {
    if (results.responseJSON != undefined && !results.responseJSON.HasErrors) {
        $('.account_profile_panel').removeClass('editable');
    }
}
function ChangePassword_OnFailure(results) {

}
$(document).on("click", "#btnChangePassSave", function () {
    var changePassFieldError = [];
    if ($("#currentpassword").val() == "") {
        changePassFieldError.push("Current password");
    }
    if ($("#newpassword").val() == "") {
        changePassFieldError.push("New password");
    }
    GaTrack_AccountProfileCTA('Security', 'Save', '');
    if (changePassFieldError.length) {
        dataLayer.push({
            'error': changePassFieldError.toString()
        });
        return true;
    }

})

function ChangePassword_OnBegin(results) {

}

function SetDateOfBirth(date, iscancel = false) {
    try {
        var formattedDate = new Date(date);
        var d = (formattedDate.getDate() < 10) ? '0' + formattedDate.getDate() : formattedDate.getDate();
        var m = parseInt(formattedDate.getMonth());
        m += 1;
        var m = (m < 10) ? '0' + m : m;
        var y = formattedDate.getFullYear();
        if (iscancel) {
            $("#profileDOB").prop("value", date);
        } else {
            $("#profileDOBHidden").prop("value", date);
            $('.profile-dob').text(d + "/" + m + "/" + y);
        }

    } catch (error) {
        console.log(error);
    }

}


//Profile Information
function ProfileInformationForm_OnSuccess(results) {
    if (results.HasErrors) {
        if ($('#phonenumber').val() == ""
            || $('#pasms').is(':checked')
            || $('#gcsms').is(':checked')
            || $('#cssms').is(':checked')
            || $('#dsc_sms').is(':checked')
            || $('#dsc_phone').is(':checked')) {
            if ($('#phonenumber') == "") {
                $('.profile-phone-error').removeClass('hide');
                $('.btn-save').attr('disabled', 'disabled');
            }

        }
        else {
            $('.profile-info_update_error').text(results.Errors[0])
        }
    }
    else {
        var data = results.Data;
        $('.profile-firstname').text(GetValue(data, "FirstName"));
        $('.profile-lastname').text(GetValue(data, "LastName"));

        var phone = GetValue(data, "Phone");
        if (phone == "") {
            $(".PhoneNumberFormat").val("");
            $('.profile-phonenumber').text($('.profile-phonenumber').attr('data-nophone'));
            $("#phonenumber").prop("value", "");
            $('#gcsms, #pasms, #cssms, #dsc_sms, #dsc_phone').prop("checked", false);
           
            results.Data.filter(function (x) {
                if (x.Key == "CarSoldSMSAlert") {
                    x.Value = false;
                }
            });
            data = results.Data;
            $('#dsc_email').prop("checked", true);
        }
        else {
            $('#phonenumber,.PhoneNumberFormat').val(phone);
            $('.profile-phonenumber').text(phone);
        }
        var dob = GetValue(data, "DOB");
        if (dob == "") {
            $('.profile-dob').text($('.profile-dob').attr('data-nodob'));
        }
        else {
            SetDateOfBirth(dob)
            //$('#date').val(dob);
            //$('.profile-dob').text(dob);
        }
        if (phone != "") {
            if (GetValue(data, "GeneralSMSAlert") == "true") {
                $('#gcsms').prop('checked', true);
            }
            if (GetValue(data, "PriceDropSMSAlert") == "true") {
                $('#pasms').prop('checked', true);
            }
            if (GetValue(data, "CarSoldSMSAlert") == "true") {
                $('#cssms').prop('checked', true);
            }
        }
        
        var dsc_value = GetValue(data, "DealerCommunicationAlert");
        if (dsc_value != "") {
            $("input[data-value=" + dsc_value + "]").prop('checked', true)
        }

        $('.account_profile_panel').removeClass('editable');
       
    }
}
function ProfileInformationForm_OnComplete(results) {
    if (!results.responseJSON.HasErrors) {
        $('.account_profile_panel').removeClass('editable');
    }
}
function ProfileInformationForm_OnFailure(results) {

}
function AlertPreferenceForm_OnFailure(result) {
    console.log(result)
}