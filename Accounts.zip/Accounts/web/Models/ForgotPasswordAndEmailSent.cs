﻿using Echopark.Foundation.Common.Utilities;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Echopark.Feature.Accounts.Models
{
    public class ForgotPasswordAndEmailSent : CustomItem
    {

        public ForgotPasswordAndEmailSent(Item InnerItem) : base(InnerItem)
        {

        }
        #region ForgotPassword
        // public ForgotPasswordViewModel forgotPasswordViewModel { get; set; }
        public string ForgotPasswrdTitleID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswrdTitle.ToString();
            }
        }
        public string ForgotPasswrdTitle
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswrdTitle].Value;
            }
        }



        public string ForgotPassIntroCopyID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.ForgotPassIntroCopy.ToString();
            }
        }
        public MvcHtmlString ForgotPassIntroCopy
        {
            get
            {
                return new MvcHtmlString(InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.ForgotPassIntroCopy].Value);
            }
        }

        public string EmailFieldPlaceHolderID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.EmailFieldPlaceHolder.ToString();
            }
        }
        public string EmailFieldPlaceHolder
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.EmailFieldPlaceHolder].Value;
            }
        }

        public string SendCTATextID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.SendCTAText.ToString();
            }
        }
        public string SendCTAText
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.SendCTAText].Value;
            }
        }
        public string RememberPasswordID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.RememberPassword.ToString();
            }
        }
        public string RememberPassword
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.RememberPassword].Value;
            }
        }

        public string FPSignInCTAID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswordSignInCTA.ToString();
            }
        }
        public string FPSignInCTAText
        {
            get
            {
                return SitecoreUtility.GetLinkDescription(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswordSignInCTA);
            }
        }

        public string FPSignInCTALink
        {
            get
            {
                return SitecoreUtility.GetLinkURL(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswordSignInCTA);

            }
        }
        public string FPSignInCTATargetType
        {
            get
            {
                return SitecoreUtility.GetLinkTargetType(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswordSignInCTA);
            }
        }
        public string FPSignInCTAClass
        {
            get
            {
                return SitecoreUtility.GetLinkClass(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.ForgotPasswordSignInCTA);
            }
        }
        #endregion ForgotPassword


        #region EmailSent

        public string EmailSentTitleID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.EmailSentTitle.ToString();
            }
        }
        public string EmailSentTitle
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.EmailSentTitle].Value;
            }
        }
        public string EmailSentIntroCopyID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.EmailSentIntroCopy.ToString();
            }
        }
        public MvcHtmlString EmailSentIntroCopy
        {
            get
            {
                return new MvcHtmlString(InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.EmailSentIntroCopy].Value);
            }
        }
        public string NoEmailReceiveID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.NoEmailReceive.ToString();
            }
        }
        public string NoEmailReceive
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.NoEmailReceive].Value;
            }
        }

        public string ResentHeaderTextID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.ResentHeaderText.ToString();
            }
        }
        public string ResentHeaderText
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.ResentHeaderText].Value;
            }
        }
        public string ResentCTAText
        {
            get
            {
                return InnerItem?.Fields[Templates.ForgotPasswordAndEmailSent.Fields.ResentCTAText].Value;
            }
        }

        public string EmailSentCTAID
        {
            get
            {
                return Templates.ForgotPasswordAndEmailSent.Fields.EmailSentSignInCTA.ToString();
            }
        }
        public string EmailSentCTAText
        {
            get
            {
                return SitecoreUtility.GetLinkDescription(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.EmailSentSignInCTA);
            }
        }

        public string EmailSentCTALink
        {
            get
            {
                return SitecoreUtility.GetLinkURL(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.EmailSentSignInCTA);

            }
        }
        public string EmailSentCTATargetType
        {
            get
            {
                return SitecoreUtility.GetLinkTargetType(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.EmailSentSignInCTA);
            }
        }
        public string EmailSentCTAClass
        {
            get
            {
                return SitecoreUtility.GetLinkClass(InnerItem, Templates.ForgotPasswordAndEmailSent.Fields.EmailSentSignInCTA);
            }
        }
        #endregion EmailSent
    }
}