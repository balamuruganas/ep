﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Security;

namespace Echopark.Feature.Accounts
{

    /// <summary>
    /// Defines the <see cref="PasswordMinLengthAttribute" />
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class PasswordMinLengthAttribute : MinLengthAttribute
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the class,to check minimum required password lenght.
        /// </summary>
        public PasswordMinLengthAttribute() : base(Membership.MinRequiredPasswordLength)
        {
        }

        #endregion
    }
}
