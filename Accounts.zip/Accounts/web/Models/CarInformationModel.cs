﻿using Echopark.Foundation.Common;
using Echopark.Foundation.Common.Extensions;
using Echopark.Foundation.Common.Utilities;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Web.Mvc;

namespace Echopark.Feature.Accounts.Models
{
    public class CarInformationModel : Sitecore.Commerce.XA.Foundation.Common.Models.BaseCommerceRenderingModel
    {
        public static Item DataSource => SitecoreUtility.GetRenderingDatasourceItem() ?? SitecoreUtility.GetContextItem();

        [Required(ErrorMessageResourceName = nameof(CurrentCarMakeMissingMessage), ErrorMessageResourceType = typeof(CarInformationModel))]
        public string PreferredVehicleMake { get; set; }
        //[Required(ErrorMessageResourceName = nameof(CurrentCarModelMissingMessage), ErrorMessageResourceType = typeof(CarInformationModel))]
        public string PreferredVehicleModel { get; set; }
        [Required(ErrorMessageResourceName = nameof(PreferredCarMakeMissingMessage), ErrorMessageResourceType = typeof(CarInformationModel))]
        public string CurrentVehicleMake { get; set; }
        // [Required(ErrorMessageResourceName = nameof(PreferredCarModelMissingMessage), ErrorMessageResourceType = typeof(CarInformationModel))]
        public string CurrentVehicleModel { get; set; }

        public string UserName { get; set; }

        public List<SelectListItem> CurrentCarMakeList { get; set; }
        public List<SelectListItem> CurrentCarModelList { get; set; }

        public List<SelectListItem> PreferredCarMakeList { get; set; }
        public List<SelectListItem> PreferredCarModelList { get; set; }

        public string CarInformationHeader { get; set; }
        public string CurrentCarTitle { get; set; }
        public string CurrentCarDescription { get; set; }
        public string CurrentCarMakeLabel { get; set; }
        public string CurrentCarModelLabel { get; set; }
        public string CurrentCarDropDownMakeLabel { get; set; }
        public string CurrentCarDropDownModelLabel { get; set; }
        public static string CurrentCarMakeMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileCarInformation.Fields.CurrentCarMakeMissingMessage);
        public static string CurrentCarModelMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileCarInformation.Fields.CurrentCarModelMissingMessage);
        public string PreferredCarTitle { get; set; }
        public string PreferredCarDescription { get; set; }
        public string PreferredCarMakeLabel { get; set; }
        public string PreferredCarModelLabel { get; set; }
        public string PreferredCarDropDownMakeLabel { get; set; }
        public string PreferredCarDropDownModelLabel { get; set; }
        public static string PreferredCarMakeMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileCarInformation.Fields.PreferredCarMakeMissingMessage);
        public static string PreferredCarModelMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileCarInformation.Fields.PreferredCarModelMissingMessage);
        public string EditLinkLabel { get; set; }
        public string SaveButtonLabel { get; set; }
        public string CancelButtonLabel { get; set; }

        public void Initialize(IRendering rendering, Sitecore.Commerce.Entities.Customers.CommerceUser user = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            if (user != null)
            {
                UserName = Context.User.LocalName;
                try
                {
                    PreferredVehicleMake = user.GetPropertyValue("PreferredVehicleMake") as string;
                    PreferredVehicleModel = user.GetPropertyValue("PreferredVehicleModel") as string;
                    CurrentVehicleMake = user.GetPropertyValue("CurrentVehicleMake") as string;
                    CurrentVehicleModel = user.GetPropertyValue("CurrentVehicleModel") as string;
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                }
            }
            if (rendering != null && rendering.Item != null)
            {
                Item item = rendering.Item;
                CarInformationHeader = item.Fields[Templates.ProfileCarInformation.Fields.CarInformationHeader]?.Value;
                CurrentCarTitle = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarTitle]?.Value;
                CurrentCarDescription = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarDescription]?.Value;
                CurrentCarMakeLabel = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarMakeLabel]?.Value;
                CurrentCarModelLabel = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarModelLabel]?.Value;
                CurrentCarDropDownMakeLabel = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarDropDownMakeLabel]?.Value;
                CurrentCarDropDownModelLabel = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarDropDownModelLabel]?.Value;
                CurrentCarMakeMissingMessage = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarMakeMissingMessage]?.Value;
                CurrentCarModelMissingMessage = item.Fields[Templates.ProfileCarInformation.Fields.CurrentCarModelMissingMessage]?.Value;
                PreferredCarTitle = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarTitle]?.Value;
                PreferredCarDescription = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarDescription]?.Value;
                PreferredCarMakeLabel = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarMakeLabel]?.Value;
                PreferredCarModelLabel = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarModelLabel]?.Value;
                PreferredCarDropDownMakeLabel = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarDropDownMakeLabel]?.Value;
                PreferredCarDropDownModelLabel = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarDropDownModelLabel]?.Value;
                PreferredCarMakeMissingMessage = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarMakeMissingMessage]?.Value;
                PreferredCarModelMissingMessage = item.Fields[Templates.ProfileCarInformation.Fields.PreferredCarModelMissingMessage]?.Value;
                EditLinkLabel = item.Fields[Templates.ProfileCarInformation.Fields.EditLinkLabel]?.Value;
                SaveButtonLabel = item.Fields[Templates.ProfileCarInformation.Fields.SaveButtonLabel]?.Value;
                CancelButtonLabel = item.Fields[Templates.ProfileCarInformation.Fields.CancelButtonLabel]?.Value;
                PreferredCarMakeList = new List<SelectListItem>() { new SelectListItem() { Text = PreferredCarDropDownMakeLabel } };
                PreferredCarModelList = new List<SelectListItem>() { new SelectListItem() { Text = PreferredCarDropDownModelLabel } };
                CurrentCarMakeList = new List<SelectListItem>() { new SelectListItem() { Text = CurrentCarDropDownMakeLabel } };
                CurrentCarModelList = new List<SelectListItem>() { new SelectListItem() { Text = CurrentCarDropDownModelLabel } };
            }
        }
    }
}