﻿namespace Echopark.Feature.Accounts.Infrastructure.Pipelines
{
    using Echopark.Foundation.Common;
    using Echopark.Foundation.Common.Utilities;
    using Sitecore.Commerce;
    using Sitecore.Commerce.Core.Commands;
    using Sitecore.Commerce.Engine;
    using Sitecore.Commerce.Engine.Connect.Pipelines;
    using Sitecore.Commerce.Entities;
    using Sitecore.Commerce.Entities.Customers;
    using Sitecore.Commerce.EntityViews;
    using Sitecore.Commerce.Pipelines;
    using Sitecore.Commerce.Plugin.Customers;
    using Sitecore.Commerce.Services;
    using Sitecore.Commerce.Services.Customers;
    using System;
    using System.Linq;
    using System.Reflection;

    public class CreateUser : PipelineProcessor
    {
        public IEntityFactory EntityFactory
        {
            get;
            private set;
        }

        public CreateUser(IEntityFactory entityFactory)
        {
            EntityFactory = entityFactory;
        }

        public override void Process(ServicePipelineArgs args)
        {
            PipelineUtility.ValidateArguments<CreateUserRequest, CreateUserResult>(args, out var request, out var result);
            Sitecore.Diagnostics.Assert.IsNotNull(request.UserName, "request.UserName");
            Sitecore.Diagnostics.Assert.IsNotNull(request.Password, "request.Password");
            Container container = GetContainer(request.Shop.Name, string.Empty, "", "", args.Request.CurrencyCode);
            CommerceUser commerceUser = result.CommerceUser;
            if (commerceUser != null && commerceUser.UserName.Equals(request.UserName, StringComparison.OrdinalIgnoreCase))
            {
                string entityId = "Entity-Customer-" + request.UserName;
                ServiceProviderResult serviceProviderResult = new ServiceProviderResult();
                EntityView entityView = GetEntityView(container, entityId, string.Empty, "Details", string.Empty, serviceProviderResult);
                if (serviceProviderResult.Success && !string.IsNullOrEmpty(entityView.EntityId))
                {
                    base.Process(args);
                    return;
                }
            }
            EntityView entityView2 = GetEntityView(container, string.Empty, string.Empty, "Details", "AddCustomer", result);
            if (!result.Success)
            {
                return;
            }
            entityView2.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("Domain", StringComparison.OrdinalIgnoreCase)).Value = request.UserName.Split('\\')[0];
            entityView2.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("LoginName", StringComparison.OrdinalIgnoreCase)).Value = request.UserName.Split('\\')[1];
            entityView2.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("AccountStatus", StringComparison.OrdinalIgnoreCase)).Value = "ActiveAccount";
            if (!string.IsNullOrEmpty(request.Email))
            {
                entityView2.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals("Email", StringComparison.OrdinalIgnoreCase)).Value = request.Email;
            }
            try
            {
                foreach (PropertyItem property in request.Properties)
                {
                    ViewProperty propertyExist = entityView2.Properties.FirstOrDefault((ViewProperty p) => p.Name.Equals(property.Key, StringComparison.OrdinalIgnoreCase));

                    if (propertyExist == null)
                    {
                        entityView2.Properties.Add(new ViewProperty()
                        {
                            Name = property.Key,
                            Value = property.Value?.ToString()
                        });
                    }
                    else
                    {
                        propertyExist.Name = property.Key;
                        propertyExist.Value = property.Value?.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }
            CommerceCommand commerceCommand = DoAction(container, entityView2, result);
            if (commerceCommand != null && commerceCommand.ResponseCode.Equals("ok", StringComparison.OrdinalIgnoreCase))
            {
                CommerceUser commerceUser2 = EntityFactory.Create<CommerceUser>("CommerceUser");
                commerceUser2.Email = request.Email;
                commerceUser2.UserName = request.UserName;
                commerceUser2.ExternalId = commerceCommand.Models.OfType<CustomerAdded>().FirstOrDefault().CustomerId;
                result.CommerceUser = commerceUser2;
                request.Properties.Add(new PropertyItem
                {
                    Key = "UserId",
                    Value = result.CommerceUser.ExternalId
                });
            }
            base.Process(args);
        }
    }
}