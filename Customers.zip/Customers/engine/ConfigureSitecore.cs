﻿namespace Echopark.Plugin.Customers
{
    using Echopark.Plugin.Customers.Pipelines.Blocks;
    using Microsoft.Extensions.DependencyInjection;
    using Sitecore.Commerce.Core;
    using Sitecore.Commerce.EntityViews;
    using Sitecore.Framework.Configuration;
    using Sitecore.Framework.Pipelines.Definitions.Extensions;
    using System.Reflection;

    /// <summary>
    /// The Habitat configure class.
    /// </summary>
    /// <seealso cref="IConfigureSitecore" />
    public class ConfigureSitecore : IConfigureSitecore
    {
        /// <summary>
        /// The configure services.
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            var assembly = Assembly.GetExecutingAssembly();
            services.RegisterAllPipelineBlocks(assembly);

            services.Sitecore().Pipelines(config => config
                    .ConfigurePipeline<IGetEntityViewPipeline>(c =>
                    {
                        c.Replace<Sitecore.Commerce.Plugin.Customers.GetCustomerDetailsViewBlock, ExtendedGetCustomerDetailsViewBlock>();
                    }));
        }
    }
}