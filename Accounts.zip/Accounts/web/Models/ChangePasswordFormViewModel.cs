﻿
namespace Echopark.Feature.Accounts.Models
{
    using Echopark.Foundation.Common;
    using System.ComponentModel.DataAnnotations;

    public class ChangePasswordFormViewModel
    {
        public static string PasswordMustContain => CommonDictionaryValues.ValidationMessages.PasswordMustContain;

        ///Minimum six characters, Max. 16 characters, 
        ///at least one uppercase letter, at least one lowercase letter and 
        ///at least one number
        [Required(ErrorMessageResourceName = nameof(PasswordMustContain), ErrorMessageResourceType = typeof(ChangePasswordFormViewModel))]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d\W]{6,16}$", ErrorMessageResourceName = nameof(PasswordMustContain), ErrorMessageResourceType = typeof(ChangePasswordFormViewModel))]
        public string NewPassword { get; set; }

        public ChangePasswordFormDatasource ChangePasswordFormDatasource { get; set; }

        public string QueryStringParams { get; set; }

        public bool IsValidToken { get; set; }
    }
}