﻿using Sitecore.Commerce.XA.Feature.Account.Models;
using Sitecore.Commerce.XA.Foundation.Common.Context;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Echopark.Feature.Accounts.Models
{
    public class ChangePasswordRenderingViewModel: ChangePasswordRenderingModel
    {
		public ChangePasswordRenderingModel changePasswordRenderingModel { get; set; }
		public  ChangePasswordRenderingViewModel(IStorefrontContext storefrontContext, IContext context) : base(storefrontContext, context)
		{
		}
		[Required]
		[DataType(DataType.Password)]
		[Display(Name = "Confirm new password")]
		[Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
		public string ConfirmPassword { get; set; }

		public IContext Context { get; }

		
		[Required(ErrorMessage = "{0} is required")]
		[DataType(DataType.Password)]
		[Display(Name = "New password")]
		[MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
		[RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,}$", ErrorMessage = "Password is invalid")]
		public string NewPassword { get; set; }

		[Required]
		[DataType(DataType.Password)]
		[Display(Name = "Current password")]
		public string OldPassword { get; set; }

		[NotMapped]
		public string ErrorMessage { get; set; }
	}
}