﻿namespace Echopark.Feature.Accounts.Models
{
    using Sitecore.Commerce.Entities.Customers;
    using Sitecore.Diagnostics;
    using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;

    public static class ProfileViewMockData
	{
		public static ProfileInformationModel ProfileInfoInitializeMockData(IRendering rendering, ProfileInformationModel model)
		{
			Assert.ArgumentNotNull(model, "model");
			model.Initialize(rendering, GetMockUser());
			return model;
		}
		public static ProfileViewRenderingViewModel InitializeMockData(IRendering rendering, ProfileViewRenderingViewModel model)
		{
			Assert.ArgumentNotNull(model, "model");
			model.Initialize(rendering, GetMockUser());
			return model;
		}
		public static CarInformationModel CarInfoInitializeMockData(IRendering rendering, CarInformationModel model)
		{
			Assert.ArgumentNotNull(model, "model");
			model.Initialize(rendering, GetMockUser());
			return model;
		}
		public static ChangePasswordEditorModel ChangePasswordInitializeMockData(IRendering rendering, ChangePasswordEditorModel model)
		{
			Assert.ArgumentNotNull(model, "model");
			model.Initialize(rendering, GetMockUser());
			return model;
		}
		public static AlertPreferenceModel AlertInitializeMockData(IRendering rendering, AlertPreferenceModel model)
		{
			Assert.ArgumentNotNull(model, "model");
			model.Initialize(rendering, GetMockUser());
			return model;
		}

		private static CommerceUser GetMockUser()
		{
			return new CommerceUser
			{
				FirstName = "Lorem",
				LastName = "Ipsum",
				Email = "morbi.elementum@hendrerit.mi"
			};
		}
	}

}