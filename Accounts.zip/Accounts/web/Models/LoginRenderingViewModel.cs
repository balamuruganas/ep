﻿using Echopark.Foundation.Common.Utilities;
using Sitecore.Commerce.XA.Feature.Account.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Echopark.Feature.Accounts.Models
{
    public class LoginRenderingViewModel : LoginRenderingModel
    {
        /// <summary>
        /// Gets the EmailLabel
        public static string EmailLabel => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.Labels.Email);

        /// <summary>
        /// Gets the EmailRequiredErrorMessage

        public static string EmailRequiredErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ValidationMessages.EmailRequired);

        /// <summary>
        /// Gets the Invalid Email Address Error Message
        /// </summary>
        public static string InvalidEmailAddressErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ValidationMessages.InvalidEmailAddress);

        /// <summary>
        /// Gets the Minimum Password Length Error Message
        /// </summary>
        public static string MinimumPasswordLengthErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ValidationMessages.MinimumPasswordLength);

        /// <summary>
        /// Gets the password label 
        /// </summary>
        public static string PasswordLabel => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.Labels.Password);

        /// <summary>
        /// Gets the password required errormessage
        /// </summary>
        public static string PasswordRequiredErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ValidationMessages.PasswordRequired);

        /// <summary>
        /// Gets or sets the password
        /// </summary>
        [Display(Name = nameof(PasswordLabel), ResourceType = typeof(LoginRenderingViewModel))]
        [Required(ErrorMessageResourceName = nameof(PasswordRequiredErrorMessage), ErrorMessageResourceType = typeof(LoginRenderingViewModel))]
        [MinLength(6, ErrorMessageResourceName = nameof(MinimumPasswordLengthErrorMessage), ErrorMessageResourceType = typeof(LoginRenderingViewModel))]
        [DataType(DataType.Password)]
        public new string Password { get; set; }

        /// <summary>
        /// Gets or sets the emaid
        /// </summary>
        [Display(Name = nameof(EmailLabel), ResourceType = typeof(LoginRenderingViewModel))]
        [Required(ErrorMessageResourceName = nameof(EmailRequiredErrorMessage), ErrorMessageResourceType = typeof(LoginRenderingViewModel))]
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessageResourceName = nameof(InvalidEmailAddressErrorMessage), ErrorMessageResourceType = typeof(LoginRenderingViewModel))]
        [DataType(DataType.EmailAddress)]
        public new string UserName { get; set; }

        /// <summary>
        /// Gets or sets the RememberMe
        /// </summary>
        public new bool RememberMe { get; set; } = true;
        /// <summary>
        /// Gets or sets the returnurl
        /// </summary>
        public string ReturnUrl { get; set; }
        /// <summary>
        /// Define the invalid login error message
        /// </summary>
        public static string InvalidLoginErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ErrroMessages.LoginFailed);
        /// <summary>
        /// Define the internal server errormessage
        /// </summary>
        public static string InternalServerErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ErrroMessages.InternalServerErrorMessage);

        /// <summary>
        /// Define the user does not exist
        /// </summary>
        public static string UserNotExistErrorMessage => SitecoreUtility.GetDictionaryValue(AccountConstants.Dictionary.SingIn.ErrroMessages.UserNotExist);
        /// <summary>
        /// Define the default page after login
        /// </summary>
        public static string DefaultPageAfterLogin => SitecoreUtility.GetLinkURL((SitecoreUtility.GetRenderingDatasourceItem() ?? SitecoreUtility.GetContextItem()), AccountConstants.Template.Login.Fields.DefaultPageAfterPage);
    }
}