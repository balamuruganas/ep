﻿
namespace Echopark.Feature.Accounts.Controllers
{
    using Echopark.Feature.Accounts.Models;
    using Echopark.Foundation.Accounts.Models.Checkout;
    using Echopark.Foundation.Accounts.Services;
    using Echopark.Foundation.Common;
    using Echopark.Foundation.Common.Utilities;
    using Newtonsoft;
    using Newtonsoft.Json;
    using Sitecore.Commerce.Entities.Customers;
    using Sitecore.Commerce.XA.Feature.Account.Models;
    using Sitecore.Commerce.XA.Feature.Account.Models.JsonResults;
    using Sitecore.Commerce.XA.Feature.Account.Repositories;
    using Sitecore.Commerce.XA.Foundation.Common.Attributes;
    using Sitecore.Commerce.XA.Foundation.Common.Context;
    using Sitecore.Commerce.XA.Foundation.Common.Models;
    using Sitecore.Commerce.XA.Foundation.Common.Models.JsonResults;
    using Sitecore.Commerce.XA.Foundation.Connect.Managers;
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Linq;
    using System.Reflection;
    using System.Web.Mvc;
    using System.Web.SessionState;
    using System.Web.UI;
    using EFA = Echopark.Foundation.Accounts;

    public class EchoParkLoginController : Sitecore.Commerce.XA.Feature.Account.Controllers.AccountController
    {
        private AccountsService accountsService = new AccountsService();

        public EchoParkLoginController(ILoginRepository loginRepository, IRegistrationRepository registrationRepository, IForgotPasswordRepository forgotPasswordRepository, IChangePasswordRepository changePasswordRepository, IAccountManager accountManager, IStorefrontContext storefrontContext, IModelProvider modelProvider, IContext sitecoreContext, IRegisterUserRepository registerUserRepository, ILoginUserRepository loginUserRepository) : base(loginRepository, registrationRepository, forgotPasswordRepository, changePasswordRepository, accountManager, storefrontContext, modelProvider, sitecoreContext, registerUserRepository, loginUserRepository)
        {
        }
        [HttpGet]
        [AllowAnonymous]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult LoginUser(string returnurl = "")
        {
            try
            {
                LoginRenderingViewModel loginRenderingViewModel = new LoginRenderingViewModel();

                if (string.IsNullOrEmpty(returnurl))
                {
                    returnurl = Request.Url.PathAndQuery;
                }

                loginRenderingViewModel.ReturnUrl = string.IsNullOrEmpty(returnurl) ? LoginRenderingViewModel.DefaultPageAfterLogin : returnurl;
                return View(AccountConstants.ViewPaths.Login.LoginView, loginRenderingViewModel);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Redirect(CommonConstants.RelativePageUrls.Error);
            }

        }

        [HttpPost]
        [ValidateHttpPostHandler]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult LoginUser(LoginRenderingViewModel model)
        {
            BaseJsonResult baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
            try
            {
                ValidateModel(baseJsonResult);
                if (baseJsonResult.HasErrors)
                {
                    return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
                }
                var user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + model.UserName).Result;
                if (user == null)
                {
                    baseJsonResult.SetError(LoginRenderingViewModel.UserNotExistErrorMessage);
                    return Json(baseJsonResult, JsonRequestBehavior.AllowGet);
                }
                if (ModelState.IsValid)
                {
                    baseJsonResult = LoginUserRepository.LoginUser(base.StorefrontContext, VisitorContext, model.UserName, model.Password, model.RememberMe);
                    if (baseJsonResult.HasErrors)
                    {
                        baseJsonResult.SetError(LoginRenderingViewModel.InternalServerErrorMessage);
                    }
                    else if (baseJsonResult.HasInfo && !baseJsonResult.Success)
                    {
                        baseJsonResult.SetError(LoginRenderingViewModel.InvalidLoginErrorMessage);
                    }
                }
                else
                {
                    baseJsonResult.SetWarnings((from modelValue in (ModelState.Values)
                                                where ((IEnumerable<ModelError>)modelValue.Errors).Any()
                                                from error in (IEnumerable<ModelError>)modelValue.Errors
                                                select error.ErrorMessage).ToList());
                }
            }
            catch (Exception ex)
            {
                baseJsonResult.Success = false;
                baseJsonResult.Errors.Add(ex.Message);
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }
            return Json(baseJsonResult);
        }

        [Authorize]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult UserChangePassword()
        {

            try
            {
                ChangePasswordRenderingModel changePasswordModel = ChangePasswordRepository.GetChangePasswordModel(base.Rendering);
                ChangePasswordRenderingViewModel changePasswordRendering = new ChangePasswordRenderingViewModel(StorefrontContext, SitecoreContext);
                changePasswordRendering.changePasswordRenderingModel = changePasswordModel;
                return View(AccountConstants.ViewPaths.Login.ChangePassword, changePasswordRendering);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Redirect(CommonConstants.RelativePageUrls.Error);
            }

        }

        [HttpPost]
        [ValidateHttpPostHandler]
        [Authorize]
        //[ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult UserChangePassword(ChangePasswordModel inputModel)
        {
            try
            {

                ChangePasswordBaseJsonResult result = new ChangePasswordBaseJsonResult(this.StorefrontContext, this.SitecoreContext);
                if (!System.Web.Security.Membership.ValidateUser(VisitorContext.UserName, inputModel.OldPassword))
                {
                    result.SetError("Incorrect Password");
                    result.Success = false;
                    return Json(result);
                }

                this.ValidateModel(result);
                if (result.HasErrors)
                {
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
                var response = this.AccountManager.ChangeUserPassword(this.VisitorContext, inputModel.OldPassword, inputModel.NewPassword);
                result = new ChangePasswordBaseJsonResult(this.StorefrontContext, this.SitecoreContext);
                if (response.ServiceProviderResult.Success)
                {
                    result.Initialize(this.VisitorContext.UserName);
                    result.SetInfo(base.StorefrontContext.GetSystemMessage("Change Password Success"));
                }
                return Json(result);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Json(new BaseJsonResult("ChangePassword", ex, base.StorefrontContext, base.SitecoreContext), JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public ActionResult Logout()
        {
            try
            {
                AccountManager.Logout();
                return RedirectToLocal(base.StorefrontContext.StorefrontUri(base.StorefrontContext.CurrentStorefront.Home).Uri.AbsoluteUri);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Redirect(CommonConstants.RelativePageUrls.Error);
            }

        }


        [HttpPost]
        [ValidateHttpPostHandler]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult LoginUserFromCheckout(CheckoutPersonalDetailsProfile dataModel)
        {
            int statusCode = 0;
            string message = string.Empty;
            string exception = string.Empty;
            BaseJsonResult baseJsonResult = null;
            dynamic personalInfo = null;
            string piJson = string.Empty;

            try
            {
                if (dataModel != null && dataModel.UserProfilePersonalDetails != null)
                {
                    ///setting dummy values as they will not be available from view, checkout login.
                    string dummyPassword = "Aaaaa1";
                    dataModel.UserProfilePersonalDetails.Password = dummyPassword;
                    dataModel.UserProfilePersonalDetails.ConfirmPassword = dummyPassword;

                    if (!dataModel.IsForFinance)
                    {
                        dataModel.UserProfilePersonalDetails.SSN = "000000000";
                    }

                    baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
                    ValidateModel(baseJsonResult);
                    ModelState.Clear();

                    if (ModelState.IsValid)
                    {
                        CommerceUser user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + dataModel.UserProfilePersonalDetails.Email).Result;

                        if (user == null)
                        {
                            statusCode = 2;
                            message = LoginRenderingViewModel.UserNotExistErrorMessage;
                            baseJsonResult.SetError(message);
                        }
                        else
                        {
                            baseJsonResult = LoginUserRepository.LoginUser(base.StorefrontContext, VisitorContext, dataModel.UserProfilePersonalDetails.Email, dataModel.UserProfilePersonalDetails.CheckoutWelcomeBackPassword, false);

                            if (baseJsonResult.Success)
                            {
                                if (HelperUtility.IsValidAge(dataModel.UserProfilePersonalDetails.DateOfBirth, CommonDictionaryValues.Checkout.ApplicantMinAge, CommonDictionaryValues.Checkout.ApplicantMaxAge))
                                {
                                    personalInfo = new ExpandoObject();
                                    personalInfo.FirstName = accountsService.GetCurrentCommerceUserFirstName(); ;
                                    personalInfo.LastName = accountsService.GetCurrentCommerceUserLastName();
                                    personalInfo.Email = accountsService.GetCurrentCommerceUserEmail();
                                    personalInfo.Phone = Convert.ToString(accountsService.GetCurrentCommerceUserProfilePropertyValue(EFA.AccountConstants.UserProfileProperties.ProfilePhone)); ;
                                    personalInfo.DOB = dataModel.UserProfilePersonalDetails.DateOfBirth != null ? dataModel.UserProfilePersonalDetails.DateOfBirth?.ToString("yyyy-MM-dd") : "";
                                    string dob = Convert.ToString(accountsService.GetCurrentCommerceUserProfilePropertyValue(EFA.AccountConstants.UserProfileProperties.DOB));
                                    personalInfo.DOB = dob;
                                    piJson = JsonConvert.SerializeObject(personalInfo);
                                    statusCode = 1; 
                                }
                                else
                                {
                                    message = CommonDictionaryValues.ValidationMessages.ApplicantAgeLimit;
                                }
                            }
                            else
                            {
                                statusCode = 0;

                                if (baseJsonResult.HasErrors)
                                {
                                    baseJsonResult.SetError(LoginRenderingViewModel.InternalServerErrorMessage);
                                    message = LoginRenderingViewModel.InternalServerErrorMessage;
                                }
                                else if (baseJsonResult.HasInfo && !baseJsonResult.Success)
                                {
                                    baseJsonResult.SetError(LoginRenderingViewModel.InvalidLoginErrorMessage);
                                    message = LoginRenderingViewModel.InvalidLoginErrorMessage;
                                }
                                else
                                {
                                    message = CommonDictionaryValues.ValidationMessages.GenericError;
                                }
                            }
                        }
                    }
                    else
                    {
                        statusCode = 0;
                        message = CommonDictionaryValues.ValidationMessages.GenericError;
                        baseJsonResult.SetWarnings((from modelValue in (ModelState.Values)
                                                    where ((IEnumerable<ModelError>)modelValue.Errors).Any()
                                                    from error in (IEnumerable<ModelError>)modelValue.Errors
                                                    select error.ErrorMessage).ToList());
                    }
                }
                else
                {
                    message = CommonDictionaryValues.ValidationMessages.GenericError;
                    exception = EFA.DictionaryValues.Registration.ErrorMessage.InvalidRegistrationRequest;
                }
            }
            catch (Exception ex)
            {
                statusCode = 0;
                message = CommonDictionaryValues.ValidationMessages.GenericError;
                exception = ex.ToString();
                baseJsonResult.Success = false;
                baseJsonResult.Errors.Add(exception);
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }

            return Json(new { Status = statusCode, Message = message, Exception = exception, BaseJsonResult = baseJsonResult, PersonalInfo = piJson });
        }

        [HttpPost]
        [ValidateHttpPostHandler]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult CheckoutCashFlowLogin(CashFlowPersonalDetails dataModel)
        {
            int statusCode = 0;
            string message = string.Empty;
            string exception = string.Empty;
            BaseJsonResult baseJsonResult = null;
            dynamic personalInfo = null;
            string piJson = string.Empty;

            try
            {
                ModelState.Remove(nameof(dataModel.Password));
                ModelState.Remove(nameof(dataModel.ConfirmPassword));
                if (dataModel != null)
                {
                    baseJsonResult = new BaseJsonResult(base.SitecoreContext, base.StorefrontContext);
                    ValidateModel(baseJsonResult);
                    ModelState.Clear();

                    if (ModelState.IsValid)
                    {
                        CommerceUser user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + dataModel.Email).Result;

                        if (user == null)
                        {
                            statusCode = 2;
                            message = LoginRenderingViewModel.UserNotExistErrorMessage;
                            baseJsonResult.SetError(message);
                        }
                        else
                        {
                            baseJsonResult = LoginUserRepository.LoginUser(base.StorefrontContext, VisitorContext, dataModel.Email, dataModel.CheckoutWelcomeBackPassword, false);

                            if (baseJsonResult.Success)
                            {
                                personalInfo = new ExpandoObject();
                                personalInfo.FirstName = accountsService.GetCurrentCommerceUserFirstName(); ;
                                personalInfo.LastName = accountsService.GetCurrentCommerceUserLastName();
                                personalInfo.Email = accountsService.GetCurrentCommerceUserEmail();
                                personalInfo.Phone = Convert.ToString(accountsService.GetCurrentCommerceUserProfilePropertyValue(EFA.AccountConstants.UserProfileProperties.ProfilePhone)); ;
                                piJson = JsonConvert.SerializeObject(personalInfo);
                                statusCode = 1;
                            }
                            else
                            {
                                statusCode = 0;

                                if (baseJsonResult.HasErrors)
                                {
                                    baseJsonResult.SetError(LoginRenderingViewModel.InternalServerErrorMessage);
                                    message = LoginRenderingViewModel.InternalServerErrorMessage;
                                }
                                else if (baseJsonResult.HasInfo && !baseJsonResult.Success)
                                {
                                    baseJsonResult.SetError(LoginRenderingViewModel.InvalidLoginErrorMessage);
                                    message = LoginRenderingViewModel.InvalidLoginErrorMessage;
                                }
                                else
                                {
                                    message = CommonDictionaryValues.ValidationMessages.GenericError;
                                }
                            }
                        }
                    }
                    else
                    {
                        statusCode = 0;
                        message = CommonDictionaryValues.ValidationMessages.GenericError;
                        baseJsonResult.SetWarnings((from modelValue in (ModelState.Values)
                                                    where ((IEnumerable<ModelError>)modelValue.Errors).Any()
                                                    from error in (IEnumerable<ModelError>)modelValue.Errors
                                                    select error.ErrorMessage).ToList());
                    }
                }
                else
                {
                    message = CommonDictionaryValues.ValidationMessages.GenericError;
                    exception = EFA.DictionaryValues.Registration.ErrorMessage.InvalidRegistrationRequest;
                }
            }
            catch (Exception ex)
            {
                statusCode = 0;
                message = CommonDictionaryValues.ValidationMessages.GenericError;
                exception = ex.ToString();
                baseJsonResult.Success = false;
                baseJsonResult.Errors.Add(exception);
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }

            return Json(new { Status = statusCode, Message = message, Exception = exception, BaseJsonResult = baseJsonResult, PersonalInfo = piJson });
        }
    }
}