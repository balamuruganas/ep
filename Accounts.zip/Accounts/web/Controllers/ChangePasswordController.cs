﻿
namespace Echopark.Feature.Accounts.Controllers
{
    using Echopark.Feature.Accounts.Models;
    using Echopark.Foundation.Accounts.Services;
    using Echopark.Foundation.Common;
    using Echopark.Foundation.Common.Utilities;
    using Sitecore;
    using Sitecore.Data.Items;
    using System;
    using System.Reflection;
    using System.Web.Mvc;

    public class ChangePasswordController : Controller
    {
        private AccountsService accountsService = new AccountsService();

        public ActionResult RenderChangePasswordForm(string t)
        {
            bool isValidToken = false;
            string usernameWithDomain = string.Empty;
            ChangePasswordFormViewModel viewModel = new ChangePasswordFormViewModel();

            try
            {
                isValidToken = IsValidToken(t, true, out usernameWithDomain);

                if (isValidToken)
                {
                    Item datasourceItem = SitecoreUtility.GetRenderingDatasourceItem();

                    if (datasourceItem != null && datasourceItem.TemplateID == Templates.ChangePasswordFormDatasource.ID)
                    {
                        viewModel.IsValidToken = true;
                        viewModel.ChangePasswordFormDatasource = new ChangePasswordFormDatasource(datasourceItem);

                        if (viewModel.ChangePasswordFormDatasource.IsActive)
                        {
                            viewModel.QueryStringParams = t;
                        }
                        else
                        {
                            viewModel = null;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }

            return View(AccountConstants.ViewPaths.FolderPath + "ChangePasswordForm.cshtml", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult ChangeUserPassword(ChangePasswordFormViewModel model)
        {
            int statusCode = 0;
            string message = string.Empty;
            string usernameWithDomain = string.Empty;

            try
            {
                if (ModelState.IsValid)
                {
                    if (IsValidToken(model.QueryStringParams, false, out usernameWithDomain))
                    {
                        ///update pwd
                        accountsService.UpdatePassword(usernameWithDomain, model.NewPassword);                        

                        ///login user
                        accountsService.LoginUser(usernameWithDomain, model.NewPassword);
                        message = model.QueryStringParams;
                        statusCode = 1;
                    }
                    else
                    {
                        statusCode = 2;                        
                    }
                }
                else
                {
                    statusCode = -1;
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                message = CommonDictionaryValues.ValidationMessages.GenericError;
            }

            return Json(new { Status = statusCode, Message = message });
        }

        public ActionResult RenderPasswordChangedSection(string t)
        {
            bool isValidToken = false;
            string usernameWithDomain = string.Empty;
            PasswordChangedSection viewModel = null;

            try
            {
                isValidToken = IsValidToken(t, true, out usernameWithDomain);

                if (isValidToken)
                {
                    Item datasourceItem = SitecoreUtility.GetRenderingDatasourceItem();

                    if (datasourceItem != null && datasourceItem.TemplateID == Templates.PasswordChangedSection.ID)
                    {
                        viewModel = new PasswordChangedSection(datasourceItem);

                        if (!viewModel.IsActive)
                        {
                            viewModel = null;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }

            if (isValidToken)
            {
                return View(AccountConstants.ViewPaths.FolderPath + "PasswordChangedSection.cshtml", viewModel);
            }
            else
            {
                return Redirect(CommonConstants.RelativePageUrls.PageNotFound);
            }
        }

        private bool IsValidToken(string queryStringParams, bool checkTokenExpiry, out string usernameWithDomain)
        {
            usernameWithDomain = string.Empty;
            bool isValidToken = false;

            if (!string.IsNullOrEmpty(queryStringParams))
            {
                queryStringParams = queryStringParams.Replace(CommonConstants.Characters.Space, CommonConstants.Characters.Plus);
                string decryptedQueryStringParams = StringCipher.Decrypt(queryStringParams);

                if (!string.IsNullOrEmpty(decryptedQueryStringParams))
                {
                    string[] qsParams = decryptedQueryStringParams.Split(CommonConstants.Characters.Pipe);

                    if (qsParams != null && qsParams.Length == 2)
                    {
                        usernameWithDomain = qsParams[0];
                        string tokenParam = qsParams[1];

                        if (accountsService.GetUserByUsername(usernameWithDomain, true) != null)
                        {
                            string storedToken = System.Convert.ToString(accountsService.GetCustomProfilePropertyValue(usernameWithDomain, AccountConstants.ProfileProperties.ForgotPasswordToken));

                            if (storedToken == tokenParam)
                            {
                                int isTokenUsed = MainUtil.GetInt(accountsService.GetCustomProfilePropertyValue(usernameWithDomain, AccountConstants.ProfileProperties.IsForgotPasswordTokenUsed), 0);

                                if (isTokenUsed == 0)
                                {
                                    if (checkTokenExpiry)
                                    {
                                        DateTime tokenCreatedDate;

                                        if (DateTime.TryParse(System.Convert.ToString(accountsService.GetCustomProfilePropertyValue(usernameWithDomain, AccountConstants.ProfileProperties.ForgotPasswordTokenCreatedDate)), out tokenCreatedDate))
                                        {
                                            TimeSpan ts = DateTime.Now - tokenCreatedDate;
                                            isValidToken = ts.TotalMinutes < CustomSettings.Accounts.ForgotPasswordTokenExpiryMinutes;
                                        }
                                    }
                                    else
                                    {
                                        isValidToken = true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            usernameWithDomain = string.Empty;
                        }
                    }
                }
            }

            return isValidToken;
        }
    }
}