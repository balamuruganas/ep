﻿using Echopark.Feature.Accounts.Models;
using Echopark.Feature.Accounts.Repositories;
using Echopark.Feature.Base;
using Echopark.Foundation.Accounts.Models;
using Echopark.Foundation.Accounts.Models.Checkout;
using Echopark.Foundation.Common;
using Echopark.Foundation.Common.Utilities;
using Sitecore.Commerce.Entities.Customers;
using Sitecore.Commerce.XA.Feature.Account.Models.JsonResults;
using Sitecore.Commerce.XA.Feature.Account.Repositories;
using Sitecore.Commerce.XA.Foundation.Common;
using Sitecore.Commerce.XA.Foundation.Common.Attributes;
using Sitecore.Commerce.XA.Foundation.Common.Context;
using Sitecore.Commerce.XA.Foundation.Common.Models;
using Sitecore.Commerce.XA.Foundation.Common.Models.JsonResults;
using Sitecore.Commerce.XA.Foundation.Connect.Managers;
using System;
using System.Reflection;
using System.Web.Mvc;
using System.Web.SessionState;
using System.Web.UI;
using EFA = Echopark.Foundation.Accounts;

namespace Echopark.Feature.Accounts.Controllers
{
    public class RegistrationController : Sitecore.Commerce.XA.Feature.Account.Controllers.AccountController
    {

        public IRegistrationUserRepository RegistrationUserRepository { get; set; }

        public RegistrationController(ILoginRepository loginRepository,
            IRegistrationRepository registrationRepository,
            IForgotPasswordRepository forgotPasswordRepository
            , IChangePasswordRepository changePasswordRepository,
            IAccountManager accountManager,
            IStorefrontContext storefrontContext,
            IModelProvider modelProvider,
            IContext sitecoreContext,
            IRegisterUserRepository registerUserRepository,
            ILoginUserRepository loginUserRepository,
            IRegistrationUserRepository registrationUserRepository
            ) : base(loginRepository, registrationRepository, forgotPasswordRepository, changePasswordRepository, accountManager, storefrontContext, modelProvider, sitecoreContext, registerUserRepository, loginUserRepository)
        {

            RegistrationUserRepository = registrationUserRepository;
        }

        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        [StorefrontSessionState(SessionStateBehavior.ReadOnly)]
        public ActionResult RegisterUser(string returnurl = null)
        {
            try
            {
                RegistrationUserRenderingViewModel registrationUserRenderingViewModel = new RegistrationUserRenderingViewModel();
                registrationUserRenderingViewModel.ReturnUrl = returnurl ?? string.Empty;
                return View("~/Views/Echopark/Account/Registration.cshtml", registrationUserRenderingViewModel);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Redirect(CommonConstants.RelativePageUrls.Error);
            }

        }
        [HttpPost]
        [ValidateHttpPostHandler]
        [ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult RegisterUser(RegistrationUserRenderingViewModel inputModel)
        {
            try
            {
                RegistrationBaseJsonResult registrationBaseJsonResult = new RegistrationBaseJsonResult(base.StorefrontContext, base.SitecoreContext);
                ValidateModel(registrationBaseJsonResult);
                if (registrationBaseJsonResult.HasErrors)
                {
                    return Json(registrationBaseJsonResult, JsonRequestBehavior.AllowGet);
                }
                if (!ModelState.IsValid)
                {
                    registrationBaseJsonResult.SetError(RegistrationUserRenderingViewModel.InvalidRegistrationRequest);
                    return Json(registrationBaseJsonResult, JsonRequestBehavior.AllowGet);
                }
                var user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + inputModel.UserName).Result;
                if (user != null)
                {
                    registrationBaseJsonResult.SetError(RegistrationUserRenderingViewModel.UserAlreadyExistErrorMessage);
                    return Json(registrationBaseJsonResult, JsonRequestBehavior.AllowGet);
                }
                StringPropertyCollection propertyBag = new StringPropertyCollection
                     {
                        { "FirstName",inputModel.FirstName },
                        { "LastName",inputModel.LastName  },
                        { "PhoneNumber",inputModel.PhoneNumber  },
                        { "ReceiveEchoparkCommunications",inputModel.ReceiveEchoparkCommunications.ToString()},
                        { "GeneralEmailAlert",inputModel.ReceiveEchoparkCommunications.ToString()},
                        { "GeneralSMSAlert",inputModel.OptintoSMSfromEchoPark.ToString()}
                    };
                registrationBaseJsonResult = RegisterUserRepository.RegisterUser(VisitorContext, base.StorefrontContext, inputModel.UserName, inputModel.Password, inputModel.UserName, propertyBag);
                if (registrationBaseJsonResult.HasErrors)
                {
                    registrationBaseJsonResult.SetError(RegistrationUserRenderingViewModel.InternalServerErrorMessage);
                }
                else
                {
                    registrationBaseJsonResult.Data = RegistrationUserRepository.NotifyUserOnRegistration(inputModel.UserName, inputModel.FirstName, inputModel.LastName);
                }
                return Json(registrationBaseJsonResult);
            }
            catch (Exception exception)
            {
                return Json(new BaseJsonResult("Registration", exception, base.StorefrontContext, base.SitecoreContext), JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult RenderAccountCreatedView()
        {
            try
            {
                return View(AccountConstants.ViewPaths.Registration.AccountCreatedView);
            }
            catch (Exception ex)
            {

                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                return Redirect(CommonConstants.RelativePageUrls.Error);
            }

        }

        [HttpPost]
        [ValidateHttpPostHandler]
        //[ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult CreateAccountFromCheckout(CheckoutPersonalDetailsProfile dataModel)
        {
            int statusCode = 0;
            string message = string.Empty;
            string exception = string.Empty;
            RegistrationBaseJsonResult registrationBaseJsonResult = null;

            try
            {
                registrationBaseJsonResult = new RegistrationBaseJsonResult(base.StorefrontContext, base.SitecoreContext);
                ValidateModel(registrationBaseJsonResult);

                if (registrationBaseJsonResult.HasErrors)
                {
                    message = CommonDictionaryValues.ValidationMessages.GenericError;
                }
                else
                {
                    if (ModelState.IsValid)
                    {
                        CommerceUser user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + dataModel.UserProfilePersonalDetails.Email).Result;

                        if (user != null)
                        {
                            statusCode = 2;
                            message = EFA.DictionaryValues.Registration.ErrorMessage.UserAlreadyExistErrorMessage;
                        }
                        else
                        {
                            if (!dataModel.IsForFinance)
                            {
                                dataModel.UserProfilePersonalDetails.SSN = "";
                            }

                            StringPropertyCollection propertyBag = new StringPropertyCollection
                             {
                                { EFA.AccountConstants.UserProfileProperties.FirstName, dataModel.UserProfilePersonalDetails.FirstName },
                                { EFA.AccountConstants.UserProfileProperties.LastName, dataModel.UserProfilePersonalDetails.LastName  },
                                { EFA.AccountConstants.UserProfileProperties.PhoneNumber, dataModel.UserProfilePersonalDetails.Phone  },
                                { EFA.AccountConstants.UserProfileProperties.DOB, dataModel.UserProfilePersonalDetails.DateOfBirth?.ToString("yyyy-MM-dd") ?? ""  },
                                { EFA.AccountConstants.UserProfileProperties.GetSMSCommunications, Convert.ToString(dataModel.UserProfilePersonalDetails.GetSMSCommunications).ToLower()},
                                { EFA.AccountConstants.UserProfileProperties.GetEmailCommunications, Convert.ToString(dataModel.UserProfilePersonalDetails.GetEmailCommunications).ToLower()}
                            };

                            registrationBaseJsonResult = RegisterUserRepository.RegisterUser(VisitorContext, base.StorefrontContext, dataModel.UserProfilePersonalDetails.Email, dataModel.UserProfilePersonalDetails.Password, dataModel.UserProfilePersonalDetails.Email, propertyBag);

                            if (registrationBaseJsonResult.HasErrors)
                            {
                                statusCode = 0;
                                message = CommonDictionaryValues.ValidationMessages.GenericError;
                            }
                            else
                            {
                                statusCode = 1;
                                registrationBaseJsonResult.Data = RegistrationUserRepository.NotifyUserOnRegistration(dataModel.UserProfilePersonalDetails.Email, dataModel.UserProfilePersonalDetails.FirstName, dataModel.UserProfilePersonalDetails.LastName);
                            }
                        }
                    }
                    else
                    {
                        message = EFA.DictionaryValues.Registration.ErrorMessage.InvalidRegistrationRequest;
                    }
                }
            }
            catch (Exception ex)
            {
                statusCode = 0;
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                message = CommonDictionaryValues.ValidationMessages.GenericError;
                exception = ex.ToString();
            }

            return Json(new { Status = statusCode, Message = message, Exception = exception, RegnBaseJsonResult = registrationBaseJsonResult });
        }

        [HttpPost]
        [ValidateHttpPostHandler]
        [ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Location = OutputCacheLocation.None)]
        public JsonResult CashFlowRegisterUser(CashFlowPersonalDetails dataModel)
        {
            int statusCode = 0;
            string message = string.Empty;
            string exception = string.Empty;
            RegistrationBaseJsonResult registrationBaseJsonResult = null;

            ModelState.Remove(nameof(dataModel.City));
            ModelState.Remove(nameof(dataModel.State));
            ModelState.Remove(nameof(dataModel.Zipcode));
            ModelState.Remove(nameof(dataModel.StreetOne));
            ModelState.Remove(nameof(dataModel.CheckoutWelcomeBackPassword));

            try
            {
                registrationBaseJsonResult = new RegistrationBaseJsonResult(base.StorefrontContext, base.SitecoreContext);
                ValidateModel(registrationBaseJsonResult);

                if (registrationBaseJsonResult.HasErrors)
                {
                    message = CommonDictionaryValues.ValidationMessages.GenericError;
                }
                else
                {
                    if (ModelState.IsValid)
                    {
                        CommerceUser user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + dataModel.Email).Result;

                        if (user != null)
                        {
                            statusCode = 2;
                            message = EFA.DictionaryValues.Registration.ErrorMessage.UserAlreadyExistErrorMessage;
                        }
                        else
                        {
                            StringPropertyCollection propertyBag = new StringPropertyCollection
                             {
                                { EFA.AccountConstants.UserProfileProperties.FirstName, dataModel.FirstName },
                                { EFA.AccountConstants.UserProfileProperties.LastName, dataModel.LastName  },
                                { EFA.AccountConstants.UserProfileProperties.PhoneNumber, dataModel.Phone  },
                                { EFA.AccountConstants.UserProfileProperties.GetSMSCommunications, Convert.ToString(dataModel.GetSMSCommunications).ToLower()},
                                { EFA.AccountConstants.UserProfileProperties.GetEmailCommunications, Convert.ToString(dataModel.GetEmailCommunications).ToLower()}
                            };

                            registrationBaseJsonResult = RegisterUserRepository.RegisterUser(VisitorContext, base.StorefrontContext, dataModel.Email, dataModel.Password, dataModel.Email, propertyBag);

                            if (registrationBaseJsonResult.HasErrors)
                            {
                                statusCode = 0;
                                message = CommonDictionaryValues.ValidationMessages.GenericError;
                            }
                            else
                            {
                                statusCode = 1;
                                registrationBaseJsonResult.Data = RegistrationUserRepository.NotifyUserOnRegistration(dataModel.Email, dataModel.FirstName, dataModel.LastName);
                            }
                        }
                    }
                    else
                    {
                        message = EFA.DictionaryValues.Registration.ErrorMessage.InvalidRegistrationRequest;
                    }
                }
            }
            catch (Exception ex)
            {
                statusCode = 0;
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                message = CommonDictionaryValues.ValidationMessages.GenericError;
                exception = ex.ToString();
            }

            return Json(new { Status = statusCode, Message = message, Exception = exception, RegnBaseJsonResult = registrationBaseJsonResult });
        }

        public ActionResult RefreshAntiForgeryToken()
        {
            return PartialView(AccountConstants.ViewPaths.FolderPath + "_AntiForgeryToken.cshtml");
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public JsonResult VerifyUserByEmail(string email)
        {
            int statusCode = 0;
            string message = string.Empty;
            string exception = string.Empty;

            try
            {
                CommerceUser user = AccountManager.GetUser(SitecoreUtility.GetContextDomain() + "\\" + email).Result;

                if (user != null)
                {
                    statusCode = 1;
                }
            }
            catch (Exception ex)
            {
                statusCode = 0;
                Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                message = CommonDictionaryValues.ValidationMessages.GenericError;
                exception = ex.ToString();
            }

            return Json(new { Status = statusCode, Message = message, Exception = exception });
        }
    }
}