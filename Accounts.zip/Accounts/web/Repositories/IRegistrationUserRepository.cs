﻿namespace Echopark.Feature.Accounts.Repositories
{
    using Echopark.Feature.Accounts.Models;
    using Sitecore.Commerce.XA.Foundation.Common;

    public interface IRegistrationUserRepository
	{
		RegistrationUserRenderingViewModel GetRegistrationViewModel(StringPropertyCollection propertyBag = null);
        StringPropertyCollection NotifyUserOnRegistration(string userName, string firstName, string lastName);

    }

}
