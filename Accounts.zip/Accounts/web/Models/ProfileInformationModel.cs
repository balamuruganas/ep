﻿using Echopark.Foundation.Common;
using Echopark.Foundation.Common.Extensions;
using Echopark.Foundation.Common.Utilities;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;
using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Reflection;

namespace Echopark.Feature.Accounts.Models
{
    public class ProfileInformationModel : Sitecore.Commerce.XA.Foundation.Common.Models.BaseCommerceRenderingModel
    {
        public string Email { get; set; }

        [Required(ErrorMessageResourceName = nameof(FirstNameMissingMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        [StringLength(maximumLength: 30, ErrorMessageResourceName = nameof(FirstNameLengthMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        public string FirstName { get; set; }

        [Required(ErrorMessageResourceName = nameof(LastNameMissingMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        [StringLength(maximumLength: 30, ErrorMessageResourceName = nameof(LastNameLengthMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        public string LastName { get; set; }

        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessageResourceName = nameof(PhoneNumberInvalidMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        public string PhoneNumber { get; set; }

       // [RegularExpression(@"^\d{4}-((0\d)|(1[012]))-(([012]\d)|3[01])$", ErrorMessageResourceName = nameof(BirthDateInvalidMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        [DataType(DataType.Date, ErrorMessageResourceName = nameof(BirthDateInvalidMessage), ErrorMessageResourceType = typeof(ProfileInformationModel))]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]

        public DateTime? DOB { get; set; }

        public string BirthDate { get; set; }

        public string UserName { get; set; }

        public string ProfileInformationHeader { get; set; }
        public string EmailLabel { get; set; }
        public string EmailTooltipText { get; set; }
        public string NameLabel { get; set; }
        public string FirstNameLabel { get; set; }
        public static string FirstNameMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.FirstNameMissingMessage);
        public static string FirstNameLengthMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.FirstNameLengthMessage);
        public string FirstNameHintText { get; set; }
        public string LastNameLabel { get; set; }
        public static string LastNameMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.LastNameMissingMessage);
        public static string LastNameLengthMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.LastNameLengthMessage);
        public string LastNameHintText { get; set; }
        public string PhoneNumberLabel { get; set; }
        public string PhoneNumberHintText { get; set; }
        public static string PhoneNumberLengthMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.PhoneNumberLengthMessage);
        public static string PhoneNumberInvalidMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.PhoneNumberInvalidMessage);
        public static string PhoneNumberMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.PhoneNumberMissingMessage);
        public string BirthdayLabel { get; set; }
        public string BirthDateNoProvidedLabel { get; set; }
        public string BirthDateLabel { get; set; }
        public static string BirthDateMissingMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.BirthDateMissingMessage);
        public static string BirthDateInvalidMessage { get; set; } = DataSource.FieldValue(Templates.ProfileInformation.Fields.BirthDateInvalidMessage);
        public string EditLinkLabel { get; set; }
        public string SaveButtonLabel { get; set; }
        public string CancelButtonLabel { get; set; }
        public string UpdateAlertKey { get; set; }
        public string UpdateAlertValue { get; set; }

        public static Item DataSource => SitecoreUtility.GetRenderingDatasourceItem() ?? SitecoreUtility.GetContextItem();

        public void Initialize(IRendering rendering, Sitecore.Commerce.Entities.Customers.CommerceUser user = null)
        {
            CultureInfo provider = CultureInfo.InvariantCulture;
            Assert.ArgumentNotNull(rendering, "rendering");
            if (user != null)
            {
                Email = user.Email;
                UserName = Context.User.LocalName;
                FirstName = user.FirstName;
                LastName = user.LastName;
                try
                {
                    PhoneNumber = user.GetPropertyValue("Phone") as string;

                    var dateBirth = user.GetPropertyValue("DOB") as string;
                    if (!string.IsNullOrEmpty(dateBirth))
                    {
                        DOB = DateTime.Parse(dateBirth);
                        BirthDate = DateTime.Parse(dateBirth).ToString("dd/MM/yyyy");
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                }
            }
            if (rendering != null && rendering.Item != null)
            {
                Item item = rendering.Item;

                ProfileInformationHeader = item.Fields[Templates.ProfileInformation.Fields.ProfileInformationHeader]?.Value;
                EmailLabel = item.Fields[Templates.ProfileInformation.Fields.EmailLabel]?.Value;
                EmailTooltipText = item.Fields[Templates.ProfileInformation.Fields.EmailTooltipText]?.Value;
                NameLabel = item.Fields[Templates.ProfileInformation.Fields.NameLabel]?.Value;
                FirstNameLabel = item.Fields[Templates.ProfileInformation.Fields.FirstNameLabel]?.Value;
                FirstNameMissingMessage = item.Fields[Templates.ProfileInformation.Fields.FirstNameMissingMessage]?.Value;
                FirstNameLengthMessage = item.Fields[Templates.ProfileInformation.Fields.FirstNameLengthMessage]?.Value;
                FirstNameHintText = item.Fields[Templates.ProfileInformation.Fields.FirstNameHintText]?.Value;
                LastNameLabel = item.Fields[Templates.ProfileInformation.Fields.LastNameLabel]?.Value;
                LastNameMissingMessage = item.Fields[Templates.ProfileInformation.Fields.LastNameMissingMessage]?.Value;
                LastNameLengthMessage = item.Fields[Templates.ProfileInformation.Fields.LastNameLengthMessage]?.Value;
                LastNameHintText = item.Fields[Templates.ProfileInformation.Fields.LastNameHintText]?.Value;
                PhoneNumberLabel = item.Fields[Templates.ProfileInformation.Fields.PhoneNumberLabel]?.Value;
                PhoneNumberHintText = item.Fields[Templates.ProfileInformation.Fields.PhoneNumberHintText]?.Value;
                PhoneNumberLengthMessage = item.Fields[Templates.ProfileInformation.Fields.PhoneNumberLengthMessage]?.Value;
                PhoneNumberInvalidMessage = item.Fields[Templates.ProfileInformation.Fields.PhoneNumberInvalidMessage]?.Value;
                PhoneNumberMissingMessage = item.Fields[Templates.ProfileInformation.Fields.PhoneNumberMissingMessage]?.Value;
                BirthdayLabel = item.Fields[Templates.ProfileInformation.Fields.BirthdayLabel]?.Value;
                BirthDateNoProvidedLabel = item.Fields[Templates.ProfileInformation.Fields.BirthDateNoProvidedLabel]?.Value;
                BirthDateLabel = item.Fields[Templates.ProfileInformation.Fields.BirthDateLabel]?.Value;
                EditLinkLabel = item.Fields[Templates.ProfileInformation.Fields.EditLinkLabel]?.Value;
                SaveButtonLabel = item.Fields[Templates.ProfileInformation.Fields.SaveButtonLabel]?.Value;
                CancelButtonLabel = item.Fields[Templates.ProfileInformation.Fields.CancelButtonLabel]?.Value;
                BirthDateMissingMessage = item.Fields[Templates.ProfileInformation.Fields.BirthDateMissingMessage]?.Value;
                BirthDateInvalidMessage = item.Fields[Templates.ProfileInformation.Fields.BirthDateInvalidMessage]?.Value;
            }
        }
    }
}