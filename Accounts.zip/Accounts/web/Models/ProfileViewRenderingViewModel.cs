﻿using Echopark.Foundation.Common;
using Echopark.Foundation.Common.Utilities;
using Sitecore.Commerce.Entities.Customers;
using Sitecore.Commerce.XA.Feature.Account.Models;
using Sitecore.Commerce.XA.Foundation.Common.Context;
using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;
using System;
using System.Reflection;

namespace Echopark.Feature.Accounts.Models
{
    public class ProfileViewRenderingViewModel : ProfileViewRenderingModel
    {
        public ProfileViewRenderingViewModel(IStorefrontContext storefrontContext, IContext sitecoreContext)
            : base(storefrontContext, sitecoreContext)
        {

        }
        public string ProfileHeaderText { get; set; }
        public string SignOutText { get; set; }
        public string SignOutLink { get; set; }

        public override void Initialize(IRendering rendering, CommerceUser user = null)
        {
            if (user != null)
            {
                Email = user.Email;
                UserName = Context.User.LocalName;
                FirstName = user.FirstName;
                LastName = user.LastName;
                try
                {
                    PhoneNumber = user.GetPropertyValue("Phone") as string;

                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
                }
            }
            if (rendering != null && rendering.Item != null)
            {
                ProfileHeaderText = rendering.Item.Fields[Templates.ProfileView.Fields.ProfileHeaderText]?.Value;
                SignOutText = rendering.Item.Fields[Templates.ProfileView.Fields.SignOutText]?.Value;
                SignOutLink = rendering.Item.Fields[Templates.ProfileView.Fields.SignOutLink]?.Value;
            }

        }
    }
}