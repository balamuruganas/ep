﻿
namespace Echopark.Feature.Accounts.Models
{
    using Echopark.Foundation.Common;
    using Sitecore.Data.Items;
    using System.Web.Mvc;

    public class PasswordChangedSection : CustomItem
    {
        public PasswordChangedSection(Item innerItem) : base(innerItem) { }

        public string ContentId
        {
            get
            {
                return Templates.PasswordChangedSection.Fields.Content.ToString();
            }
        }

        public MvcHtmlString Content
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.PasswordChangedSection.Fields.Content].Value);
            }
        }

        public bool IsActive
        {
            get
            {
                return InnerItem.Fields[CommonTemplates.ActiveStatus.Fields.IsActive].Value == CommonConstants.One;
            }
        }
    }

}