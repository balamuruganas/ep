﻿namespace Echopark.Feature.Accounts.Repositories
{
    using Echopark.Feature.Accounts.Models;
    using Echopark.Feature.Accounts.Services;
    using Echopark.Foundation.Common;
    using Echopark.Foundation.Common.Utilities;
    using Sitecore.Commerce.XA.Feature.Account.Repositories;
    using Sitecore.Commerce.XA.Foundation.Common;
    using Sitecore.Commerce.XA.Foundation.Common.Context;
    using Sitecore.Commerce.XA.Foundation.Common.Models;
    using System;
    using System.Reflection;

    public class RegistrationUserRepository : BaseAccountRepository, IRegistrationUserRepository
    {
        public RegistrationUserRepository(IModelProvider modelProvider, IStorefrontContext storefrontContext, IContext context)
            : base(modelProvider, storefrontContext, context)
        {
        }

        public RegistrationUserRenderingViewModel GetRegistrationViewModel(StringPropertyCollection propertyBag = null)
        {
            RegistrationUserRenderingViewModel model = base.ModelProvider.GetModel<RegistrationUserRenderingViewModel>();
            Init(model);
            model.Initialize(base.StorefrontContext);
            return model;
        }
        public StringPropertyCollection NotifyUserOnRegistration(string userName, string firstName, string lastName)
        {
            bool flag = false;
            try
            {
                var args = new EmailNotifyArguments()
                {
                    Event = new Event()
                    {
                        Email = userName,
                        FirstName = firstName,
                        LastName = lastName
                    },
                    EventType = Enum.GetName(typeof(EventType), EventType.CreateAccount)
                };

                flag = MailServices.NotifyUserOnCreateAccount(args);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, MethodBase.GetCurrentMethod().ReflectedType.Name + CommonConstants.Characters.Dot + MethodBase.GetCurrentMethod().Name, this);
            }
            return new StringPropertyCollection
            {
                { "IsNotifiedUserByEmail",flag.ToString() }
            };
        }
    }

}