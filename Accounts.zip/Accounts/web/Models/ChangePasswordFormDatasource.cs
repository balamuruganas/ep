﻿
namespace Echopark.Feature.Accounts.Models
{
    using Echopark.Foundation.Common;
    using Echopark.Foundation.Common.Extensions;
    using Sitecore.Data.Items;    
    using System.Web.Mvc;

    public class ChangePasswordFormDatasource : CustomItem
    {
        public ChangePasswordFormDatasource(Item innerItem) : base(innerItem) { }

        public string SectionImageId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.SectionImage.ToString();
            }
        }

        public string SectionImageUrl
        {
            get
            {
                return InnerItem.ImageUrl(Templates.ChangePasswordFormDatasource.Fields.SectionImage);
            }
        }

        public string SectionImageAlt
        {
            get
            {
                return InnerItem.ImageAlt(Templates.ChangePasswordFormDatasource.Fields.SectionImage);
            }
        }

        public string TitleId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.Title.ToString();
            }
        }

        public MvcHtmlString Title
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.Title].Value);
            }
        }

        public string DescriptionId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.Description.ToString();
            }
        }

        public MvcHtmlString Description
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.Description].Value);
            }
        }

        public string NewPasswordLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.NewPasswordLabel.ToString();
            }
        }

        public MvcHtmlString NewPasswordLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.NewPasswordLabel].Value);
            }
        }

        public string NewPasswordPlaceholderId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.NewPasswordPlaceholder.ToString();
            }
        }

        public MvcHtmlString NewPasswordPlaceholder
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.NewPasswordPlaceholder].Value);
            }
        }

        public string ConfirmPasswordLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.ConfirmPasswordLabel.ToString();
            }
        }

        public MvcHtmlString ConfirmPasswordLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.ConfirmPasswordLabel].Value);
            }
        }

        public string ConfirmPasswordPlaceholderId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.ConfirmPasswordPlaceholder.ToString();
            }
        }

        public MvcHtmlString ConfirmPasswordPlaceholder
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.ConfirmPasswordPlaceholder].Value);
            }
        }

        public string MustContainLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.MustContainLabel.ToString();
            }
        }

        public MvcHtmlString MustContainLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.MustContainLabel].Value);
            }
        }

        public string Atleast6charactersLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.Atleast6charactersLabel.ToString();
            }
        }

        public MvcHtmlString Atleast6charactersLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.Atleast6charactersLabel].Value);
            }
        }

        public string Atleast1uppercaseletterLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.Atleast1uppercaseletterLabel.ToString();
            }
        }

        public MvcHtmlString Atleast1uppercaseletterLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.Atleast1uppercaseletterLabel].Value);
            }
        }

        public string Atleast1lowercaseletterLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.Atleast1lowercaseletterLabel.ToString();
            }
        }

        public MvcHtmlString Atleast1lowercaseletterLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.Atleast1lowercaseletterLabel].Value);
            }
        }

        public string Atleast1numberLabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.Atleast1numberLabel.ToString();
            }
        }

        public MvcHtmlString Atleast1numberLabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.Atleast1numberLabel].Value);
            }
        }

        public string NewPasswordValidationMessageId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.NewPasswordValidationMessage.ToString();
            }
        }

        public string NewPasswordValidationMessage
        {
            get
            {
                return InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.NewPasswordValidationMessage].Value;
            }
        }

        public string PasswordsMismatchValidationMessageId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.PasswordsMismatchValidationMessage.ToString();
            }
        }

        public MvcHtmlString PasswordsMismatchValidationMessage
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.PasswordsMismatchValidationMessage].Value);
            }
        }

        public string CTALabelId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.CTALabel.ToString();
            }
        }

        public MvcHtmlString CTALabel
        {
            get
            {
                return new MvcHtmlString(InnerItem.Fields[Templates.ChangePasswordFormDatasource.Fields.CTALabel].Value);
            }
        }

        public bool IsActive
        {
            get
            {
                return InnerItem.Fields[CommonTemplates.ActiveStatus.Fields.IsActive].Value == CommonConstants.One;
            }
        }

        public string TokenExpiredMessageId
        {
            get
            {
                return Templates.ChangePasswordFormDatasource.Fields.TokenExpiredMessage.ToString();
            }
        }

    }

}