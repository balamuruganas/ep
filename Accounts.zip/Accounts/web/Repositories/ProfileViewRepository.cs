﻿using Echopark.Feature.Accounts.Models;

namespace Echopark.Feature.Accounts.Repositories
{
    using Echopark.Foundation.Common.Utilities;
    using Sitecore.Commerce;
    using Sitecore.Commerce.Entities.Customers;
    using Sitecore.Commerce.Services.Customers;
    using Sitecore.Commerce.XA.Feature.Account.Models.InputModels;
    using Sitecore.Commerce.XA.Feature.Account.Repositories;
    using Sitecore.Commerce.XA.Foundation.Common;
    using Sitecore.Commerce.XA.Foundation.Common.Context;
    using Sitecore.Commerce.XA.Foundation.Common.Models;
    using Sitecore.Commerce.XA.Foundation.Connect;
    using Sitecore.Commerce.XA.Foundation.Connect.Managers;
    using Sitecore.Diagnostics;
    using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;
    using System.Collections.Generic;

    public class ProfileViewRepository : BaseAccountRepository, IProfileViewRepository
    {
        public ProfileViewRepository(IModelProvider modelProvider, IStorefrontContext storefrontContext, IAccountManager accountManager, IContext context)
            : base(modelProvider, storefrontContext, context)
        {
            AccountManager = accountManager;
        }

        public IAccountManager AccountManager { get; private set; }

        public ProfileEditorInputModel GetProfile(string userName, StringPropertyCollection propertyBag = null)
        {
            IVisitorContext current = VisitorContext.Current;
            ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, propertyBag);
            if (user.ServiceProviderResult.Success && user.Result != null)
            {
                return new ProfileEditorInputModel()
                {
                    FirstName = user.Result.FirstName,
                    LastName = user.Result.LastName,
                    PhoneNumber = user.Result.GetPropertyValue("Phone") as string,
                    EmailAddress = user.Result.Email
                };
            }
            return new ProfileEditorInputModel() { EmailAddress = current.UserEmail };
        }
        public StringPropertyCollection GetUserProperties()
        {
            IVisitorContext current = VisitorContext.Current;
            ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, null);
            StringPropertyCollection propertyBag = new StringPropertyCollection();
            if (user.ServiceProviderResult.Success && user.Result != null)
            {
                foreach (var property in user.Result.GetProperties())
                {
                    propertyBag.Add(property.Key, property.Value?.ToString());
                }
                if (!propertyBag.Contains("FirstName"))
                {
                    propertyBag.Add("FirstName", user.Result.FirstName);
                }
                if (!propertyBag.Contains("LastName"))
                {
                    propertyBag.Add("LastName", user.Result.LastName);
                }
            }
            return propertyBag;
        }

        public AlertPreferenceModel GetAlertPreferencesViewModel(IRendering rendering, StringPropertyCollection propertyBag = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            AlertPreferenceModel model = base.ModelProvider.GetModel<AlertPreferenceModel>();
            Init(model);
            if (!base.Context.IsExperienceEditor)
            {
                IVisitorContext current = VisitorContext.Current;
                ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, propertyBag);
                if (user.ServiceProviderResult.Success && user.Result != null)
                {
                    CommerceUser result = user.Result;
                    model.Initialize(rendering, result);
                }
                else
                {
                    model.Initialize(rendering);
                }
            }
            else
            {
                model = ProfileViewMockData.AlertInitializeMockData(rendering, model);
            }
            if (rendering.DataSourceItem == null)
            {
                model.ErrorMessage = SitecoreUtility.GetDictionaryValue(Accounts.Templates.Profile.NoDatasourceFound);
            }
            return model;
        }

        public CarInformationModel GetCarInformationViewModel(IRendering rendering, StringPropertyCollection propertyBag = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            CarInformationModel model = base.ModelProvider.GetModel<CarInformationModel>();
            Init(model);
            if (!base.Context.IsExperienceEditor)
            {
                IVisitorContext current = VisitorContext.Current;
                ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, propertyBag);
                if (user.ServiceProviderResult.Success && user.Result != null)
                {
                    CommerceUser result = user.Result;
                    model.Initialize(rendering, result);
                }
                else
                {
                    model.Initialize(rendering);
                }
            }
            else
            {
                model = ProfileViewMockData.CarInfoInitializeMockData(rendering, model);
            }
            if (rendering.DataSourceItem == null)
            {
                model.ErrorMessage = SitecoreUtility.GetDictionaryValue(Accounts.Templates.Profile.NoDatasourceFound);
            }
            return model;
        }

        public ChangePasswordEditorModel GetChangePasswordViewModel(IRendering rendering, StringPropertyCollection propertyBag = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            ChangePasswordEditorModel model = base.ModelProvider.GetModel<ChangePasswordEditorModel>();
            Init(model);
            if (!base.Context.IsExperienceEditor)
            {
                IVisitorContext current = VisitorContext.Current;
                ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, propertyBag);
                if (user.ServiceProviderResult.Success && user.Result != null)
                {
                    CommerceUser result = user.Result;
                    model.Initialize(rendering, result);
                }
                else
                {
                    model.Initialize(rendering);
                }
            }
            else
            {
                model = ProfileViewMockData.ChangePasswordInitializeMockData(rendering, model);
            }
            if (rendering.DataSourceItem == null)
            {
                model.ErrorMessage = SitecoreUtility.GetDictionaryValue(Accounts.Templates.Profile.NoDatasourceFound);
            }
            return model;
        }
        public ProfileInformationModel GetProfileInformationViewModel(IRendering rendering, StringPropertyCollection propertyBag = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            ProfileInformationModel model = base.ModelProvider.GetModel<ProfileInformationModel>();
            Init(model);
            if (!base.Context.IsExperienceEditor)
            {
                IVisitorContext current = VisitorContext.Current;
                ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, propertyBag);
                if (user.ServiceProviderResult.Success && user.Result != null)
                {
                    CommerceUser result = user.Result;
                    model.Initialize(rendering, result);
                }
                else
                {
                    model.Initialize(rendering);
                }
            }
            else
            {
                model = ProfileViewMockData.ProfileInfoInitializeMockData(rendering, model);
            }
            if (rendering.DataSourceItem == null)
            {
                model.ErrorMessage = SitecoreUtility.GetDictionaryValue(Accounts.Templates.Profile.NoDatasourceFound);
            }
            return model;
        }
        public ProfileViewRenderingViewModel GetProfileViewModel(IRendering rendering, StringPropertyCollection propertyBag = null)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            ProfileViewRenderingViewModel model = base.ModelProvider.GetModel<ProfileViewRenderingViewModel>();
            Init(model);
            if (!base.Context.IsExperienceEditor)
            {
                IVisitorContext current = VisitorContext.Current;
                ManagerResponse<GetUserResult, CommerceUser> user = AccountManager.GetUser(current.UserName, propertyBag);
                if (user.ServiceProviderResult.Success && user.Result != null)
                {
                    CommerceUser result = user.Result;
                    model.Initialize(rendering, result);
                }
                else
                {
                    model.Initialize(rendering);
                }
            }
            else
            {
                model = ProfileViewMockData.InitializeMockData(rendering, model);
            }
            if (rendering.DataSourceItem == null)
            {
                model.ErrorMessage = SitecoreUtility.GetDictionaryValue(Accounts.Templates.Profile.NoDatasourceFound);
            }
            return model;
        }
    }
}