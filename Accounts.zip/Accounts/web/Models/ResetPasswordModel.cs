﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Echopark.Feature.Accounts.Models
{
    public class ResetPasswordModel
    {
        public static string _Password => "New password";
        public static string _ConfirmPassword => "Confirm password";
        public static string PasswordRequiredMsg = "New password is required.";
        public static string ConfirmPasswordNotMatchMsg = "Passwords do not match";
        public static string ConfirmPasswordRequiredMsg = "Confirm password is required.";
        public static string PasswordPatternErrorMessage => "Enter a password that is 6 or more characters, with at least 1 number, 1 uppercase letter, and 1 lowercase letter.";

        [Required(ErrorMessage = nameof(PasswordRequiredMsg))]
        [DataType(DataType.Password)]
        [Display(Name = nameof(_Password))]
        [MaxLength(16)]
        [MinLength(6, ErrorMessageResourceName = nameof(PasswordPatternErrorMessage), ErrorMessageResourceType = typeof(ChangePasswordModel))]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,}$", ErrorMessageResourceName = nameof(PasswordPatternErrorMessage), ErrorMessageResourceType = typeof(ChangePasswordModel))]
        public string NewPassword { get; set; }

        [MaxLength(16)]
        [Display(Name = nameof(_ConfirmPassword))]
        [Required(ErrorMessageResourceName = nameof(ConfirmPasswordRequiredMsg), ErrorMessageResourceType = typeof(ChangePasswordModel))]
        [Compare("NewPassword", ErrorMessageResourceName = nameof(ConfirmPasswordNotMatchMsg), ErrorMessageResourceType = typeof(ChangePasswordModel))]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}